HR.appController.addTemplate("backbone/templates/administration/challenge-edit-languages", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="challenge-languages">\n    <p class="aside block-margin margin-large">Testcases weight the strength of the code\n        and allow users to test their code before submitting. Include at least one testcase\n        for your challenge and mark whether it can be used as an example. At least one\n        example with an explaination is required.</p>\n\n    <div class="title-header">\n        <h5 class="pull-left span11pct">Language</h5>\n        <h5 class="pull-left span37pct m">Time Limit (seconds)</h5>\n        <h5 class="pull-left span37pct m">Memory Limit (MB)</h5>\n        <div class="clearfix"></div>\n    </div>\n\n    <div class="language-cards-list-container"></div>\n</div>\n';
return __p;
});