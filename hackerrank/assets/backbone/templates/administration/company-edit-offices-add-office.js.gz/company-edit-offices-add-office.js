HR.appController.addTemplate("backbone/templates/administration/company-edit-offices-add-office", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="formgroup horizontal row">\n    <label for="city" class="pull-left span3">City</label>\n    <div class="block span12 profile-input">\n        <input id="city" type="text" class="span5 auto-save"/>\n        <small class="error city span12"></small>\n    </div>\n</div>\n<div class="formgroup horizontal row">\n    <label for="country" class="pull-left span3">Country</label>\n    <div class="block span12 profile-input">\n        <input id="country" type="text" class="span5 auto-save"/>\n        <small class="error country span12"></small>\n    </div>\n</div>\n';
return __p;
});