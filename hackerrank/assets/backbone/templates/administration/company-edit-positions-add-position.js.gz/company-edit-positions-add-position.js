HR.appController.addTemplate("backbone/templates/administration/company-edit-positions-add-position", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="formgroup horizontal row">\n    <label for="name" class="pull-left span3">Name</label>\n    <div class="block span12 profile-input">\n        <input id="name" type="text" class="span5 auto-save"/>\n        <small class="error name span12"></small>\n    </div>\n</div>\n<div class="formgroup horizontal row">\n    <label for="description" class="pull-left span3">Description</label>\n    <div class="block span5 profile-input pull-left">\n        <textarea id="description" rows="6" class="pitch span5 auto-save"></textarea>\n    </div>\n</div>\n';
return __p;
});