HR.appController.addTemplate("backbone/templates/calendar", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="container--inner">\n<header class="clearfix page-title">\n	<h1 class="pull-left">\n		Programming Contest Calendar\n\n	</h1>\n</header>\n<div class="clearfix">\n    <div class="pull-left calendar-note">All timezones are in UTC</div>\n    <div class="pull-right hr_calendar_links">\n	    <a class="btn btn-text calendar_rss" href="/calendar/feed.rss" target="_blank"><i class="icon-rss"></i> Subscribe</a>\n	</div>\n</div>\n  <div id=\'calendar\'></div>\n</div>\n';
return __p;
});