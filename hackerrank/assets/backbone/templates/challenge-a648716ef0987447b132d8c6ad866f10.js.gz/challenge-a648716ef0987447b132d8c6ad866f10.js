HR.appController.addTemplate("backbone/templates/challenge", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div>\n    <div class="challenge-header">\n    </div>\n    <section class="challenge-interface">\n        <div class="challenge-body">\n        </div>\n    </section>\n</div>\n';
return __p;
});