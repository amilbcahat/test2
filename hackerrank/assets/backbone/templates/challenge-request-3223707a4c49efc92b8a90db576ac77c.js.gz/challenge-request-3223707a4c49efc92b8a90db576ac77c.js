HR.appController.addTemplate("backbone/templates/challenge-request", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="challenge-input codeeditor-wrapper"></div>\n';
return __p;
});