HR.appController.addTemplate("backbone/templates/compile-test", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="container">\n  <div class="game-container-wrapper"></div>\n</div>\n';
return __p;
});