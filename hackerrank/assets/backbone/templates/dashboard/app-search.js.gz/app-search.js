HR.appController.addTemplate("backbone/templates/dashboard/app-search", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="search-input input-icon">\n    <input type="text" id="search-text" class="search-query" autocomplete="off">\n    <i class="icon-search"></i>\n</div>\n<div class="search-result hide">\n    <ul class="unstyled"></ul>\n</div>\n';
return __p;
});