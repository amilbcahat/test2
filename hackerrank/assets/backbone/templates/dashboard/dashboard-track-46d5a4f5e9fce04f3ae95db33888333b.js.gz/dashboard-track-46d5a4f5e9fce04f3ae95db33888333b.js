HR.appController.addTemplate("backbone/templates/dashboard/dashboard-track", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="container">\n    <header class="view_header boundB">\n    </header><!-- END .track_header -->\n\n    <div class="view_body fill-light">\n    </div>\n </div>\n';
return __p;
});