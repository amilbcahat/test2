HR.appController.addTemplate("backbone/templates/dashboard/e404", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="error-container container">\n    <div class="container--inner">\n        <p style="font-size: 110px; text-shadow: 0 5px 20px rgba(0,0,0,0.4);" class="text-center"><strong>404</strong></p>\n        <p style="font-size: 30px" class="text-center span12 block-center"><strong>We could not find the page you were looking for, so we found something to make you laugh to make up for it.</p>\n        <div class="text-center">\n            <a class="btn btn-primary btn-large mlT mlB" onclick="javascript: (function() { history.back(); return false;})();">Go back a page</a>\n        </div>\n        <img src="/assets/fourohfour.png" class="block-center">\n\n    </div>\n</div>\n\n';
return __p;
});