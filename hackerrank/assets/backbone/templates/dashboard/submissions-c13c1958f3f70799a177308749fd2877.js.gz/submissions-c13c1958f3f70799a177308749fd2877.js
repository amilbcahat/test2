HR.appController.addTemplate("backbone/templates/dashboard/submissions", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += "";
return __p;
});