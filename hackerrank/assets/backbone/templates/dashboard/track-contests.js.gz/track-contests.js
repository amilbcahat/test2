HR.appController.addTemplate("backbone/templates/dashboard/track-contests", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="row">\n    <div class="span10 track_contentList challenges-list pjR">\n    </div>\n    <div class="span6">\n        <h6 class="bold msB">Active Contests</h6>\n        <ul class="lg-block mjB active_contests">\n        </ul>\n        <h6 class="bold msB">Archived Contests</h6>\n        <div class="lg-block">\n            <ul class="archived_contests">\n            </ul>\n            <div class="lg-block_footer">\n                <a class="prev up js-prev"><i class="icon-left-open icon--single"></i></a>\n                <a class="viewAll backbone" href="/contest/archived">View All</a>\n                <a class="next down js-next"><i class="icon-right-open icon--single"></i></a>\n            </div>\n        </div>\n    </div>\n</div>\n';
return __p;
});