HR.appController.addTemplate("backbone/templates/forum/challenge-questions-sidebar", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="clearfix header">\n</section>\n<section class="challenge-questions-recent-activity recent-activity">\n</section>\n';
return __p;
});