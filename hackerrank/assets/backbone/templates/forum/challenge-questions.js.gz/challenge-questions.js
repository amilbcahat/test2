HR.appController.addTemplate("backbone/templates/forum/challenge-questions", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="forum">\n    <div class="row">\n        <div id="question-list-view"></div>\n        <div class="forum-sidebar sidebar span4 pull-right"></div>\n    </div>\n</section>\n';
return __p;
});