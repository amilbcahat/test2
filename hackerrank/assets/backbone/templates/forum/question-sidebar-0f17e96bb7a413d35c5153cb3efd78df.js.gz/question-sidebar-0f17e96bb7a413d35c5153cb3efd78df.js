HR.appController.addTemplate("backbone/templates/forum/question-sidebar", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="clearfix follow-question"></div>\n<section class="related-questions related"></section>\n<section class="recent-activity question-recent-activity"></section>\n';
return __p;
});