HR.appController.addTemplate("backbone/templates/forum/question", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="forum single-question">\n    <div class="clearfix">\n        <div class="span11 margin-large left" id="question-content-view"></div>\n        <div class="span4 forum-sidebar sidebar pull-right padding-large right"></div>\n    </div>\n</section>\n';
return __p;
});