HR.appController.addTemplate("backbone/templates/game", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += "";
return __p;
});