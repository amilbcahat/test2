HR.appController.addTemplate("backbone/templates/gamecontainer", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="game-container light-wrap wrap" style="margin: auto;">\n    <div class="row" style="margin:0px;">\n        <div style="text-align: right;"><a class="close-container btn btn-white"><i class="icon icon-remove"></i></a></div>\n        <div style="margin:0px;">\n            <ul class="nav nav-tabs unstyled">\n                <li class="active"><a href="#game1" data-toggle="tab" data-player="1" class="playertab">Game 1</a></li>\n                <li><a href="#game2" data-toggle="tab" data-player="2" class="playertab">Game 2</a></li>\n            </ul>\n\n            <div class="tab-content">\n                <div class="tab-pane active" id="game1">\n                    <div id="game-grid1" class="game-grid"></div>\n                </div>\n                <div class="tab-pane" id="game2">\n                    <div id="game-grid2" class="game-grid"></div>\n                </div>\n            </div>\n\n        </div>\n    </div>\n</div>\n';
return __p;
});