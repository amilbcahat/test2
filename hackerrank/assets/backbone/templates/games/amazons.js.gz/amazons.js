HR.appController.addTemplate("backbone/templates/games/amazons", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<style>\n  .span450 { width: 450px; height: 45px;}\n  .span45 { width: 45px; height: 45px; margin: 0px;}\n  .square-criss { background-color: #FFCE9E; }\n  .square-cross { background-color: #D18B47; }\n  .game-grid {\n    margin: 0px auto;\n    width: 450px;\n    height: 450px;\n    padding: 0px;\n    padding-top: 30px;\n  }\n</style>\n\n<div>\n    <div class="game-grid-wrapper">\n    </div>\n</div>\n';
return __p;
});