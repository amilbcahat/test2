HR.appController.addTemplate("backbone/templates/games/clobber", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<style>\n    #graph-grid {\n        margin: 20px auto;\n        border: 1px solid #666;\n        background: #FFEBCD;\n    }\n    .graph-row {\n        background-color: none;\n        border: none;\n    }\n    .graph-col {\n        height: 30px;\n        width: 30px;\n        background-color: none;\n        border: 1px solid #000;\n    }\n\n    .graph-col-solid {\n        background: #333;\n    }\n\n    .black-block {\n        height: 30px;\n        width: 30px;\n        border-radius:13px;\n        border: 1px solid #000;\n        background: #474747;\n    }\n\n    .white-block {\n        height: 30px;\n        width: 30px;\n        border-radius:13px;\n        border: 1px solid #000;\n        background: #A0A0A0;\n    }\n\n</style>\n<div>\n    <div class="clobber-grid" style="display: block; margin: auto; border-radius: 10px;">\n    </div>\n</div>\n';
return __p;
});