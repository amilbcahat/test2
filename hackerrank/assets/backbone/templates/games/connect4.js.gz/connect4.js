HR.appController.addTemplate("backbone/templates/games/connect4", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<style>\n    #graph-grid {\n        margin: 20px auto;\n        border: 1px solid #666;\n        background: #0099CC;\n    }\n    .graph-row {\n        background-color: none;\n        border: none;\n    }\n    .graph-col {\n        height: 30px;\n        width: 30px;\n        background-color: #FFFFFF;\n        border-radius:15px;\n    }\n\n    .graph-col-solid {\n        background: #333;\n    }\n\n    .yellow-block {\n        height: 30px;\n        width: 30px;\n        background-color: #FFFF00;\n        border-radius:15px;\n    }\n\n    .red-block {\n        height: 30px;\n        width: 30px;\n        background-color: #FF0000;\n        border-radius:15px;\n    }\n\n</style>\n<div>\n    <div class="connect4-grid" style="display: block; margin: auto; border-radius: 10px;">\n    </div>\n</div>\n';
return __p;
});