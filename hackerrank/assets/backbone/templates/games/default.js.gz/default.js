HR.appController.addTemplate("backbone/templates/games/default", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += "<div>\n    \n</div>\n";
return __p;
});