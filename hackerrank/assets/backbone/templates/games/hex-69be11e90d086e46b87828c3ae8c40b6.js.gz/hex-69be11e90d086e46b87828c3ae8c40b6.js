HR.appController.addTemplate("backbone/templates/games/hex", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<style>\n  .spanhex1 {\n    width: 42px;\n    height: 35px;\n    margin-left: -2px;\n  }\n  .game-grid {\n    margin: 0px auto;\n    padding: 0px;\n    padding-left:0px;\n    padding-top: 10px;\n  }\n</style>\n\n<div>\n    <div class="game-grid-wrapper">\n    </div>\n</div>\n';
return __p;
});