HR.appController.addTemplate("backbone/templates/games/ministertrick", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div><div><div><div>\n\n</div></div></div></div>\n\n<style>\n    .move\n    {\n        display: block;\n        margin:20px auto;\n        width:130px;\n        height:30px;\n        background: #DDD;\n        border: 2px solid #666;\n        padding: 10px;\n        font-size: 30px;\n        text-align: center;\n        line-height: 30px;\n    }\n</style>\n<div>\n    <div class="game-grid" style="display: block; margin: auto; border-radius: 10px;">\n        \n        <div class="move">\n            \n        </div>\n\n    </div>\n</div>\n';
return __p;
});