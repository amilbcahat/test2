HR.appController.addTemplate("backbone/templates/games/pegsolitaire", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += "<style>\n  .spanhole {\n    width: 40px;\n    height: 40px;\n    margin-left: 0px;\n  }\n  .pegslot {\n    background: url('/static/games/peg_hollow.png');\n  }\n  .game-grid {\n    margin: 0 auto;\n    padding-top: 30px;\n    padding-bottom: 30px;\n  }\n\n</style>\n<div>\n    <div class=\"game-grid-wrapper\">\n    </div>\n</div>\n";
return __p;
});