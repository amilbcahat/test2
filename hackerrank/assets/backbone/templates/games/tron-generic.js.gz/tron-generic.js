HR.appController.addTemplate("backbone/templates/games/tron-generic", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<style>\n    #graph-grid {\n        margin: 20px auto;\n        border: 1px solid #666;\n        background: #fff;\n    }\n    .graph-row {\n        background-color: none;\n        border: none;\n    }\n    .graph-col {\n        height: 30px;\n        width: 30px;\n        background-color: none;\n        border: 1px solid #000;\n    }\n\n    .graph-col-solid {\n        background: #333;\n    }\n\n    .black-block {\n        height: 30px;\n        width: 30px;\n        border: 1px solid #000;\n        background: #474747;\n    }\n\n    .red-block {\n        height: 30px;\n        width: 30px;\n        border: 2px solid #000;\n        background: #FF0000;\n    }\n\n    .green-block {\n        height: 30px;\n        width: 30px;\n        border: 2px solid #000;\n        background: #00FF00;\n    }\n\n</style>\n<div>\n    <div class="tron-generic-grid" style="display: block; margin: auto; border-radius: 10px;">\n    </div>\n</div>\n';
return __p;
});