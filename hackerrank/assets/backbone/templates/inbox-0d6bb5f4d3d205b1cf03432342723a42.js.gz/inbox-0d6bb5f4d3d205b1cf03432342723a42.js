HR.appController.addTemplate("backbone/templates/inbox", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="messages container">\n    <header class="page-title container">\n        <h1>Inbox</h1>\n    </header>\n\n    <div class="container">\n        <div class="light-wrap padded messages-list-wrap messages_list"></div>\n    </div>\n</section>\n';
return __p;
});