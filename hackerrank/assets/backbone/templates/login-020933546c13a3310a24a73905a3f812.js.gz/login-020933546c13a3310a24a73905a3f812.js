HR.appController.addTemplate("backbone/templates/login", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="modal hide fade in" id="loginModal" style="display:none">\n  <div id="login-modal">\n      <div class="modal-header">\n          <button type="button" class="close" data-analytics="Cancel Login" data-dismiss="modal">x</button>\n          <div class="text">\n              <h2>You are browsing hackerrank as guest. Would you like to login?</h2>\n          </div>\n      </div>\n  </div>\n</div>\n';
return __p;
});