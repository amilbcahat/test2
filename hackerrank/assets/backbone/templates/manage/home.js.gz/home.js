HR.appController.addTemplate("backbone/templates/manage/home", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="container">\n  <div class="padded">\n    <header class="page-title">\n        <h1>Contest & Challenge Admin</h1>\n        <p class="aside padding-large top bottom">HackerRank allows you to create custom challenges and contests.</p>\n    </header>\n    <p class="text-center margin-large bottom"><a href="/manage/challenge" class="span5 block-center btn btn-xlarge btn-inverse backbone">Manage Challenges</a></p>\n    <p class="text-center margin-large top"><a href="/manage/contest" class="span5 block-center btn btn-xlarge btn-inverse backbone">Manage Contests</a></p>\n  </div>\n</section>\n';
return __p;
});