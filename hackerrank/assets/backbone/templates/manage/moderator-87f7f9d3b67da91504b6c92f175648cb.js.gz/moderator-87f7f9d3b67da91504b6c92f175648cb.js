HR.appController.addTemplate("backbone/templates/manage/moderator", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="row margin-small bottom">\n    <div class="span3">' + (null == (__t = model.username) ? "" :__t) + '</div>\n    <div class="span2"><a class="margin-large left btn btn-alert btn-small cursor moderator-del">remove</a></div>\n</div>\n';
return __p;
});