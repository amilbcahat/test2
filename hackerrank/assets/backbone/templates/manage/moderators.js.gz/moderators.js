HR.appController.addTemplate("backbone/templates/manage/moderators", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div>\n  <div>\n    <input type="text" class="moderator-input" placeholder="Moderator username">\n    <button class="btn btn-white moderator-add">Add</button>\n  </div>\n  <small class="error"></small>\n  <div class="moderators margin-large top"></div>\n</div>\n';
return __p;
});