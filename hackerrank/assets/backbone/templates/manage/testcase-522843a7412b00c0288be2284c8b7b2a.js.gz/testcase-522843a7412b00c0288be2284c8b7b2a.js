HR.appController.addTemplate("backbone/templates/manage/testcase", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="test-case-table table-wrap text-center span12 block-center row">\n  <header>\n    <div class="span1">\n      <p>Index</p>\n    </div>\n    <div class="span2">\n      <p>Input</p>\n    </div>\n    <div class="span2">\n      <p>Output</p>\n    </div>\n    <div class="span2">\n      <p>Score</p>\n    </div>\n    <div class="span1">\n      <p>Sample\n    </div>\n    <div class="span3">\n      <p>Actions</p>\n    </div>\n  </header>\n  <div class="testcase-list-wrapper table-body">\n  </div>\n  <div class="row text-left padding-large top bottom">\n    <div class="span11">\n      <a class="margin-small right btn btn-inverse addnew" href="#">Add TestCase</a>\n      <a class="btn btn-text uploadZip" href="#">Upload Zip</a>\n    </div>\n  </div>\n</div>\n';
return __p;
});