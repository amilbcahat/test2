HR.appController.addTemplate("backbone/templates/modal", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="modal fade in">\n    <div class="modal-header">\n        <button type="button" class="close btn-close" type="button" data-dismiss="modal" data-analytics="Modal Close">\xd7</button>\n        <h3 class="header-msg"></h3>\n    </div>\n    <div class="modal-body">\n    </div>\n    <div class="modal-footer">\n    </div>\n</div>\n';
return __p;
});