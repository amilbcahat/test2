HR.appController.addTemplate("backbone/templates/modal2", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="modal fade in">\n    <div class="modal-header">\n        <button type="button" class="close btn-close" type="button" data-dismiss="modal" data-analytics="Modal Close" data-analytics="' + (null == (__t = template) ? "" :__t) + ' modal closed">\xd7</button>\n        <h3 class="header-msg">' + (null == (__t = header) ? "" :__t) + '</h3>\n    </div>\n    <div class="modal-body">\n      ' + (null == (__t = body) ? "" :__t) + '\n    </div>\n    <div class="modal-footer">\n      ' + (null == (__t = footer) ? "" :__t) + "\n    </div>\n</div>\n";
return __p;
});