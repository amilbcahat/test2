HR.appController.addTemplate("backbone/templates/navigation-message", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="head">\n    <strong>Messages</strong>\n    <a class="pull-right send_message">Send a new message</a>\n</div>\n<ul class="hr_nav_messages_list">\n</ul>\n<div class="final">\n    <a class="backbone" href="/inbox">Show All</a>\n</div>\n';
return __p;
});