HR.appController.addTemplate("backbone/templates/networks", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="modal fade in" id="networksModal">\n  <div id="networksCarousel" class="carousel slide">\n    <div class="modal-header text-center">\n      <h1>Welcome, ' + (null == (__t = networks.username) ? "" :__t) + '</h1>\n      <!--\n      -<a class="carousel-control left" href="#welcomeCarousel" data-slide="prev">&lsaquo;</a>\n      -<a class="carousel-control right" href="#welcomeCarousel" data-slide="next">&rsaquo;</a>\n      -->\n    </div>\n    <div class="modal-body">\n      <div class="connect-social item active front">\n        <div id="network-setup">\n        </div>\n      </div>\n      <div class="item back">\n        <div id="follow-suggestions">\n        </div>\n        <div class="formgroup horizontal clearfix">\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n';
return __p;
});