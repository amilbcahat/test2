HR.appController.addTemplate("backbone/templates/notifications", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="notifications container">\n    <div class="padded">\n    <header class="page-title">\n        <h1>Notifications</h1>\n    </header>\n\n    <div class="padded notifications-list-wrap notifications_list"></div>\n    <div class="notificationslist_pagination-wrapper pagination-wrapper"></div>\n</section>\n';
return __p;
});