HR.appController.addTemplate("backbone/templates/onboarding-modal", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="modal fade in" style="border-radius: 5px; width: 500px;">\n    <p class="plR psB plL psT"><button type="button" class="close btn-close" type="button" data-dismiss="modal" data-analytics="Modal Close"><i class="icon-cancel-small"></i></button></p>\n    <div class="modal1 onboarding_modal text-align">\n        ' + (null == (__t = body) ? "" :__t) + "\n    </div>\n</div>\n";
return __p;
});