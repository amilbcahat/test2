HR.appController.addTemplate("backbone/templates/onboarding-tutorial", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="container">\n    <div class="header plB">\n        <h3 class="text-center">Solve your first challenge</h3>\n        <p>\n            Every domain has tutorial-level challenge\n            .......................................\n        </p>\n    </div>\n    <div>\n        <div class="challenge-container pull-left span5">\n            <p>\n                Count the number of elements in an array without using count, size or length operators (or their equivalents). The input and output portions will be handled automatically by the grader. You only need to write a function with the ......\n            </p>\n        </div>\n        <div class="codeeditor-container pull-left span8">\n            <div id="codeshell-wrapper">\n            </div>\n        </div>\n    </div>\n    <div class="clearfix response-view">\n    </div>\n</div>\n';
return __p;
});