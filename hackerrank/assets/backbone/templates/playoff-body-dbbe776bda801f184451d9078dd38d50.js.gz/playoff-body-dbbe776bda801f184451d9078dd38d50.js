HR.appController.addTemplate("backbone/templates/playoff-body", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="playoffs-list-wrap"></div>\n<div class="clearfix"></div>\n';
return __p;
});