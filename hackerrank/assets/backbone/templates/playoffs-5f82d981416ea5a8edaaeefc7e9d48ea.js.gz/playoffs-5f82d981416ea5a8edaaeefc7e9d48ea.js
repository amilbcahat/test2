HR.appController.addTemplate("backbone/templates/playoffs", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="sampletemplate playoffs container">\n    <div class="header text-center"></div>\n    <div class="body light-wrap"></div>\n</section>\n';
return __p;
});