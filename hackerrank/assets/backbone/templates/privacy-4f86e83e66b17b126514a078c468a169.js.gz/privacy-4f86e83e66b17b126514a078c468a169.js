HR.appController.addTemplate("backbone/templates/privacy", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<section class="scoring container">\n<header class="page-title container"></header>\n<iframe width="960" height="2600" style="overflow: auto;" frameborder=0 src="https://www.iubenda.com/privacy-policy/151793/legal"></iframe>\n</section>\n';
return __p;
});