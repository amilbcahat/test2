HR.appController.addTemplate("backbone/templates/recruit/footer", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="text-center fnt-sz-mid">\n', test.footer_copyright && (__p += "\n  " + (null == (__t = test.footer_copyright) ? "" :__t) + "\n"), 
__p += '\n</div>\n<div class="fnt-sz-small">\n  <center class="mmT mmB">\n    <a class="mdR mdL" href="/aboutus" target="_blank">About</a>\n    <a class="mdR" href="/privacy" target="_blank">Privacy policy</a>\n    <a class="mdR" href="/tos" target="_blank">Terms of service</a>\n  <center>\n</div>\n\n';
return __p;
});