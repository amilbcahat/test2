HR.appController.addTemplate("backbone/templates/recruit/footer", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="text-center">\n', test.footer_copyright && (__p += "\n  " + (null == (__t = test.footer_copyright) ? "" :__t) + "\n"), 
__p += "\n\n</div>\n";
return __p;
});