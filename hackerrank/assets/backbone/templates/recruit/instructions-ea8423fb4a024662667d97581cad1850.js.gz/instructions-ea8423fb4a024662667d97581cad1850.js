HR.appController.addTemplate("backbone/templates/recruit/instructions", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="container" style="margin-top:63px;">\n\n	<div class="test-instruction-wrapper">\n		<span class="challengeslist_challenge-title green-title customer-title-font-color">INSTRUCTIONS</span>\n        ' + (null == (__t = instructions) ? "" :__t) + "\n	</div>\n\n</div>\n";
return __p;
});