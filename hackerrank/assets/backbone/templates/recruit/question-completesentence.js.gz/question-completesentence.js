HR.appController.addTemplate("backbone/templates/recruit/question-completesentence", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="span13">\n</div>\n<div class="clear"></div>\n';
return __p;
});