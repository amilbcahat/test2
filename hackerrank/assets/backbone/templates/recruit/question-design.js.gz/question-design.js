HR.appController.addTemplate("backbone/templates/recruit/question-design", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div id="editor" class="codeshell mlT mlB"></div>\n\n<div class="output-area-wrap hidden">\n  <div class="output-area padded light-wrap" id="output-area">\n    <p class="status">Status: <span class="status-msg">Uploading..</span></p>\n  </div>\n</div>\n\n<div class="span16 hidden center-block light-wrap" style="height:600px;" id="runstatus-load">\n  <div class=\'gray\'> <div style=\'background: url(https://d3rpyts3de3lx8.cloudfront.net/hackerrank/hackerrank_spinner_64x64.gif); height: 64px; width: 64px; display: inline-block;\'></div> </div>\n</div>\n<iframe class="span16 no-padding hidden light-wrap" height="600px" name="runstatus" id="runstatus" src="">\n</iframe>\n';
return __p;
});