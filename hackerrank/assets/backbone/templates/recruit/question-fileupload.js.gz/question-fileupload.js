HR.appController.addTemplate("backbone/templates/recruit/question-fileupload", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<h5 >ANSWER - Please upload your file here</h5>\n\n<div class="inline-block mlT current-answer-section hidden">\n    Current Answer: <span id="current_answer" style="padding-left: 10px"></span>\n</div>\n\n<div class="inline-block mlT">\n    <input type="file" name="answer" title="Choose a file">\n</div>\n';
return __p;
});