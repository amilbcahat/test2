HR.appController.addTemplate("backbone/templates/recruit/question-subjective", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<h5 class="">ANSWER</h5>\n<em class="fnt-sz-small grey" style="font-weight: 500;">Your answer will be periodically saved as a draft.</em>\n<div id="editor" class="codeshell msT mlB"></div>\n';
return __p;
});