HR.appController.addTemplate("backbone/templates/recruit/question-uml", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div id= "geEditor" class="geEditor"  ></div>\n<input name="draw_xml" id="draw_xml" type="hidden" ></input>\n<input name="draw_svg" id="draw_svg" type="hidden" ></input>\n<br />\n<p class="font20 f-weight-600">ANSWER</p>\n<em class="fnt-sz-small grey" style="font-weight: 500;">Your answer will be periodically saved as a draft.</em>\n<div id="editor" class="codeshell msT mlB"></div>\n';
return __p;
});