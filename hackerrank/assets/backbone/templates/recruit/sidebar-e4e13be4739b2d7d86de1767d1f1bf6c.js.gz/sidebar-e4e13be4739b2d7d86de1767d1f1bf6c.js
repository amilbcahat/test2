HR.appController.addTemplate("backbone/templates/recruit/sidebar", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div id="side-navigation">\n    <nav class="page_navigation-sidebar expand hr_slide-away-element ligter-sidebar hr-candidate-rules" id="sidebar" style="top: 61px;">\n        <div class="mini-dash" style="display:none">\n            <!--<footer class="clearfix">\n                <p class="pull-left rank"><i class="icon-up-dir-1 success"></i> 5572<span class="sub-label">Points</span></p>\n                <p class="pull-right rank"><i class="icon-up-dir-1 success"></i> 242<span class="sub-label">Rank</span></p>\n                -->\n        </div>\n        <ul class="unstyled sidebar_nav-list sidebar-differentiator margin-top-fix fixed-nav questions-indicator">\n        </ul>\n\n        <div class="sidebar-scroll-list-container">\n            <ul class="unstyled sidebar_nav-list psT questions-indicator questions-nav">\n            </ul>\n        </div>\n    </nav>\n</div>\n';
return __p;
});