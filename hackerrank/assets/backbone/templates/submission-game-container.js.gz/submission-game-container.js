HR.appController.addTemplate("backbone/templates/submission-game-container", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div id="game-view-container"></div>\n<br>\n';
return __p;
});