HR.appController.addTemplate("backbone/templates/submission-game-set-list", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="submissions--game_list-item row push">\n    <span class="players"></span>\n    <a class="play_game submissions--game_list-btn span3 btn btn-inverse pull-right" href="">View Match</a>\n</div>\n\n<div class="submission-game-container-wrapper"></div>\n';
return __p;
});