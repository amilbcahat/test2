HR.appController.addTemplate("backbone/templates/submission-game-set", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += "<div class=\"light-wrap game-set-wrapper\">\n    <div class='throbber' style='padding: 121px 0; height: 64px;'>\n        <img src='https://d3rpyts3de3lx8.cloudfront.net/hackerrank/hackerrank_spinner_64x64.gif'>\n    </div>\n</div>\n<div class=\"pagination-wrap clearfix pagination-wrapper\"></div>\n";
return __p;
});