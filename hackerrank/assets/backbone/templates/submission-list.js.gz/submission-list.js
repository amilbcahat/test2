HR.appController.addTemplate("backbone/templates/submission-list", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += "Submission LIST\n";
return __p;
});