HR.appController.addTemplate("backbone/templates/tracks", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="container content_wrap">\n    <div class="container--inner plT">\n        <div class="row tracks_list">\n            ' + (null == (__t = HR.appController.viewLoader(64)) ? "" :__t) + "\n        </div>\n    </div>\n</div>\n";
return __p;
});