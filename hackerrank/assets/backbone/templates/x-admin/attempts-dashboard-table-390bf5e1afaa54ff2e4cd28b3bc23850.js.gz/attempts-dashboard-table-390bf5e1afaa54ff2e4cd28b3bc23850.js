HR.appController.addTemplate("backbone/templates/x-admin/attempts-dashboard-table", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="main-content">\n    <table cellpadding="0" cellspacing="0" border="0" class="attempts-table table dt-sleektable">\n        <thead>\n        <tr>\n            <td>ID</td>\n            <td>Company ID</td>\n            <td>Company Name</td>\n            <td>Candidate Name</td>\n            <td>Candidate Email</td>\n            <td>Test ID</td>\n            <td>Test Name</td>\n            <td>Invited By</td>\n        </tr>\n        </thead>\n    </table>\n</div>\n';
return __p;
});