HR.appController.addTemplate("backbone/templates/x-admin/home", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="top-fixed-bar">\n    <h3 class="topbar-h3 mjL">Admin Section</h3>\n</div>\n\n<div class="overflow-content" id="control-overflow">\n<div class="mjA">\n    <h2>\n        With admin power comes admin responsibility :P. Don\'t mess around unless you know what you are doing\n    </h2>\n</div>\n\n</div>\n';
return __p;
});