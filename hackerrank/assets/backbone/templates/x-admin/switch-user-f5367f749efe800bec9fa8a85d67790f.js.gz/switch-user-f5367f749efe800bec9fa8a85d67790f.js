HR.appController.addTemplate("backbone/templates/x-admin/switch-user", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="top-fixed-bar">\n    <h3 class="topbar-h3 mjL">Switch User</h3>\n</div>\n\n<div class="overflow-content" id="control-overflow">\n    <form id="su-form" class="mjA">\n        <div class="msT msB">\n            <div class="span13">\n                <input type="text" class="wide" name=email id="su-email" placeholder="Enter Email Address">\n            </div>\n        </div>\n\n        <div class="row no-margin plT">\n            <div class="span-xs-16 span-md-16">\n                <button type="submit" id="su-submit" class="btn btn-primary btn-mid">Skadoosh !!\n                </button>\n            </div>\n        </div>\n    </form>\n\n    <div class="mjA hidden message-box">\n    </div>\n</div>\n';
return __p;
});