HR.appController.addTemplate("backbone/templates/x-analytics/company-license-usage", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="data-section-title mlT mlB">\n    <h3>License Usage</h3>\n</div>\n\n<div class="basic-info-container mlL">\n    <div class="mjT">\n        <div class="btn-group">\n            <a href="#" class="btn graph-type-change ', 
"teams_time" == graphType && (__p += " active btn-primary "), __p += '"\n               data-graph-type="teams_time">Teams vs Time</a>\n            <a href="#" class="btn graph-type-change ', 
"users_time" == graphType && (__p += " active btn-primary "), __p += '"\n               data-graph-type="users_time">Users vs Time</a>\n        </div>\n    </div>\n\n    <div class="section mlT">\n        <div id="data-sub-section-container">\n\n        </div>\n    </div>\n</div>\n';
return __p;
});