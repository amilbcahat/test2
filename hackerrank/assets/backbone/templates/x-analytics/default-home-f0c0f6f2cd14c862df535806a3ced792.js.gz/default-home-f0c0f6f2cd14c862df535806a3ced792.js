HR.appController.addTemplate("backbone/templates/x-analytics/default-home", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="mlA">\n    <h2>Analytics Home Page; Do something useful here later</h2>\n</div>\n';
return __p;
});