HR.appController.addTemplate("backbone/templates/x/add-users-to-team", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="modal modal-mid fade" id="remove-user-modal">\n    <div class="modal-header">\n        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">\xd7</button>\n        <div class="underline_title">\n            <h3 class="text-center">Add users to team</h3>\n        </div>\n    </div>\n    <form name="add-users-to-team-form">\n        <div class="modal-body">\n            <div class="pjL pjR mlB clearfix">\n                <div class="formgroup span-md-8 plL no-margin">\n                    <label>TEAM</label>\n                    <input type="text" name="user-teams-select" class="span-xs-14">\n                </div>\n            </div>\n        </div><!-- end .modal-body -->\n        <div class="modal-footer">\n            <div class="text-left mjL">\n                <a href="#" class="btn btn-primary span2 mmR js-add-users-to-team">Yes</a>\n                <a href="" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Cancel</a>\n            </div>\n        </div>\n    </form>\n</div>\n';
return __p;
});