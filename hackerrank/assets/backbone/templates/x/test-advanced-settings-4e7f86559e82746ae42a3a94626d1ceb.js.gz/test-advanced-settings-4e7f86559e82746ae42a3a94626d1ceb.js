HR.appController.addTemplate("backbone/templates/x/test-advanced-settings", function(obj) {
{
var __t, __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="top-fixed-bar">\n    <h3 class="topbar-h3 mjL">' + (null == (__t = model.name) ? "" :_.escape(__t)) + '</h3>\n    <h3 class="topbar-h3"><i class="icon-right-open breadcrumb-chevron"></i>Advanced Settings</h3>\n</div>\n<div class="overflow-content" id="control-overflow">\n    <div id="custom_link"></div>\n    <div class="soft-divider"></div>\n\n    <div id="time_settings"></div>\n    <div class="soft-divider"></div>\n\n    <div id="test_admin"></div>\n    <div class="soft-divider"></div>\n\n    <div id="cutoff_score"></div>\n    <div class="soft-divider"></div>\n\n    <div id="mcq_score"></div>\n    <div class="soft-divider"></div>\n\n    <div id="master_password"></div>\n    <div class="soft-divider"></div>\n\n    <div id="questions_shuffling"></div>\n    <div class="soft-divider"></div>\n\n    <div id="allowed_languages"></div>\n    <div class="soft-divider"></div>\n\n    <div id="candidate_options"></div>\n    <div class="soft-divider"></div>\n\n    <div id="duplicate_test"></div>\n    <div class="soft-divider"></div>\n\n    <div id="delete_test"></div>\n    <div class="soft-divider"></div>\n</div>\n';
return __p;
});