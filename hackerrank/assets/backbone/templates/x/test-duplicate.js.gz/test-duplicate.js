HR.appController.addTemplate("backbone/templates/x/test-duplicate", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="mjA">\n    <label class="label-title-underline">\n        CLONE TEST\n    </label>\n    <div class="clear"></div>\n    <p class="txt-alt-grey span6 no-padding">Make a copy of the test.</p>\n    <a class="btn btn-primary margin-large right mdL" data-throbber="show" id="clone_test">Clone Test</a>\n    <div class="clear"></div>\n</div>\n';
return __p;
});