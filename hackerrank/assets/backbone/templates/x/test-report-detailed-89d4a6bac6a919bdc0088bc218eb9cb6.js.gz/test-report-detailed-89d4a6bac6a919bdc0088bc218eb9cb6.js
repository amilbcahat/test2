HR.appController.addTemplate("backbone/templates/x/test-report-detailed", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div class="mjA" id="detailed-report">\n</div>\n';
return __p;
});