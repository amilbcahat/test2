HR.appController.addTemplate("backbone/templates/x/test-update-saved-message-dialog", function(obj) {
{
var __p = "";
Array.prototype.join;
}
with (obj || {}) __p += '<div id="test-update-saved-message-modal" class="modal modal-mid">\n    <div class="modal-header text-center">\n        <button type="button" class="close hidden" data-dismiss="modal" aria-hidden="true">&times;</button>\n        <h4>Update Message</h4>\n    </div>\n\n    <div class="modal-body">\n        <div class="psA">\n            <div>This will overwrite the old saved response. Are You sure?</div>\n        </div>\n    </div>\n\n    <div class="modal-footer">\n        <a href="#" class="btn cancel-dialog">Cancel</a>\n        <a href="#" data-throbber="show" class="btn btn-primary update-saved-message">Yes</a>\n    </div>\n</div>\n';
return __p;
});