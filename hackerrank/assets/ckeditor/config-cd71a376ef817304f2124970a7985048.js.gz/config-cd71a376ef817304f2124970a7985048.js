/**
 * Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.editorConfig = function(config) {
config.contentsCss = [ document.getElementById("hr_typography_link").href, "https://hrcdn.net/hackerrank/assets/hackerrank-core-62591891d3906e5fd9704c68215456fe.css", "https://hrcdn.net/hackerrank/assets/libraries-1c9dfe176ae90dd01ab6753eedeec982.css", "https://hrcdn.net/hackerrank/assets/hackerrank-6507f04614d952d4b28cb0e89ac180e2.css" ];
};