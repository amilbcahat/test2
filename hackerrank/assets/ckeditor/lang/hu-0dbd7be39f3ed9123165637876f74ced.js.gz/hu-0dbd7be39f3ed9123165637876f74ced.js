/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.lang.hu = {
undo:{
redo:"Ism\xe9tl\xe9s",
undo:"Visszavon\xe1s"
},
toolbar:{
toolbarCollapse:"Eszk\xf6zt\xe1r \xf6sszecsuk\xe1sa",
toolbarExpand:"Eszk\xf6zt\xe1r sz\xe9tnyit\xe1sa",
toolbarGroups:{
document:"Dokumentum",
clipboard:"V\xe1g\xf3lap/Visszavon\xe1s",
editing:"Szerkeszt\xe9s",
forms:"\u0170rlapok",
basicstyles:"Alapst\xedlusok",
paragraph:"Bekezd\xe9s",
links:"Hivatkoz\xe1sok",
insert:"Besz\xfar\xe1s",
styles:"St\xedlusok",
colors:"Sz\xednek",
tools:"Eszk\xf6z\xf6k"
},
toolbars:"Szerkeszt\u0151 Eszk\xf6zt\xe1r"
},
templates:{
button:"Sablonok",
emptyListMsg:"(Nincs sablon megadva)",
insertOption:"Kicser\xe9li a jelenlegi tartalmat",
options:"Sablon opci\xf3k",
selectPromptMsg:"V\xe1lassza ki melyik sablon ny\xedljon meg a szerkeszt\u0151ben<br>(a jelenlegi tartalom elveszik):",
title:"El\xe9rhet\u0151 sablonok"
},
table:{
border:"Szeg\xe9lym\xe9ret",
caption:"Felirat",
cell:{
menu:"Cella",
insertBefore:"Besz\xfar\xe1s balra",
insertAfter:"Besz\xfar\xe1s jobbra",
deleteCell:"Cell\xe1k t\xf6rl\xe9se",
merge:"Cell\xe1k egyes\xedt\xe9se",
mergeRight:"Cell\xe1k egyes\xedt\xe9se jobbra",
mergeDown:"Cell\xe1k egyes\xedt\xe9se lefel\xe9",
splitHorizontal:"Cell\xe1k sz\xe9tv\xe1laszt\xe1sa v\xedzszintesen",
splitVertical:"Cell\xe1k sz\xe9tv\xe1laszt\xe1sa f\xfcgg\u0151legesen",
title:"Cella tulajdons\xe1gai",
cellType:"Cella t\xedpusa",
rowSpan:"F\xfcgg\u0151leges egyes\xedt\xe9s",
colSpan:"V\xedzszintes egyes\xedt\xe9s",
wordWrap:"Hossz\xfa sorok t\xf6r\xe9se",
hAlign:"V\xedzszintes igaz\xedt\xe1s",
vAlign:"F\xfcgg\u0151leges igaz\xedt\xe1s",
alignBaseline:"Alapvonalra",
bgColor:"H\xe1tt\xe9r sz\xedne",
borderColor:"Keret sz\xedne",
data:"Adat",
header:"Fejl\xe9c",
yes:"Igen",
no:"Nem",
invalidWidth:"A sz\xe9less\xe9g mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidHeight:"A magass\xe1g mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidRowSpan:"A f\xfcgg\u0151leges egyes\xedt\xe9s mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidColSpan:"A v\xedzszintes egyes\xedt\xe9s mez\u0151be csak sz\xe1mokat \xedrhat.",
chooseColor:"V\xe1lasszon"
},
cellPad:"Cella bels\u0151 marg\xf3",
cellSpace:"Cella t\xe9rk\xf6z",
column:{
menu:"Oszlop",
insertBefore:"Besz\xfar\xe1s balra",
insertAfter:"Besz\xfar\xe1s jobbra",
deleteColumn:"Oszlopok t\xf6rl\xe9se"
},
columns:"Oszlopok",
deleteTable:"T\xe1bl\xe1zat t\xf6rl\xe9se",
headers:"Fejl\xe9cek",
headersBoth:"Mindkett\u0151",
headersColumn:"Els\u0151 oszlop",
headersNone:"Nincsenek",
headersRow:"Els\u0151 sor",
invalidBorder:"A szeg\xe9lym\xe9ret mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidCellPadding:"A cella bels\u0151 marg\xf3 mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidCellSpacing:"A cella t\xe9rk\xf6z mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidCols:"Az oszlopok sz\xe1m\xe1nak nagyobbnak kell lenni mint 0.",
invalidHeight:"A magass\xe1g mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidRows:"A sorok sz\xe1m\xe1nak nagyobbnak kell lenni mint 0.",
invalidWidth:"A sz\xe9less\xe9g mez\u0151be csak sz\xe1mokat \xedrhat.",
menu:"T\xe1bl\xe1zat tulajdons\xe1gai",
row:{
menu:"Sor",
insertBefore:"Besz\xfar\xe1s f\xf6l\xe9",
insertAfter:"Besz\xfar\xe1s al\xe1",
deleteRow:"Sorok t\xf6rl\xe9se"
},
rows:"Sorok",
summary:"Le\xedr\xe1s",
title:"T\xe1bl\xe1zat tulajdons\xe1gai",
toolbar:"T\xe1bl\xe1zat",
widthPc:"sz\xe1zal\xe9k",
widthPx:"k\xe9ppont",
widthUnit:"Sz\xe9less\xe9g egys\xe9g"
},
stylescombo:{
label:"St\xedlus",
panelTitle:"Form\xe1z\xe1si st\xedlusok",
panelTitle1:"Blokk st\xedlusok",
panelTitle2:"Inline st\xedlusok",
panelTitle3:"Objektum st\xedlusok"
},
specialchar:{
options:"Speci\xe1lis karakter opci\xf3k",
title:"Speci\xe1lis karakter v\xe1laszt\xe1sa",
toolbar:"Speci\xe1lis karakter beilleszt\xe9se"
},
sourcearea:{
toolbar:"Forr\xe1sk\xf3d"
},
smiley:{
options:"Hangulatjel opci\xf3k",
title:"Hangulatjel besz\xfar\xe1sa",
toolbar:"Hangulatjelek"
},
showblocks:{
toolbar:"Blokkok megjelen\xedt\xe9se"
},
selectall:{
toolbar:"Mindent kijel\xf6l"
},
save:{
toolbar:"Ment\xe9s"
},
removeformat:{
toolbar:"Form\xe1z\xe1s elt\xe1vol\xedt\xe1sa"
},
print:{
toolbar:"Nyomtat\xe1s"
},
preview:{
preview:"El\u0151n\xe9zet"
},
pastetext:{
button:"Beilleszt\xe9s form\xe1zatlan sz\xf6vegk\xe9nt",
title:"Beilleszt\xe9s form\xe1zatlan sz\xf6vegk\xe9nt"
},
pastefromword:{
confirmCleanup:"\xdagy t\u0171nik a beillesztett sz\xf6veget Word-b\u0151l m\xe1solt \xe1t. Meg szeretn\xe9 tiszt\xedtani a sz\xf6veget? (aj\xe1nlott)",
error:"Egy bels\u0151 hiba miatt nem siker\xfclt megtiszt\xedtani a sz\xf6veget",
title:"Beilleszt\xe9s Word-b\u0151l",
toolbar:"Beilleszt\xe9s Word-b\u0151l"
},
pagebreak:{
alt:"Oldalt\xf6r\xe9s",
toolbar:"Oldalt\xf6r\xe9s beilleszt\xe9se"
},
newpage:{
toolbar:"\xdaj oldal"
},
maximize:{
maximize:"Teljes m\xe9ret",
minimize:"Kis m\xe9ret"
},
magicline:{
title:"Sz\xfarja be a bekezd\xe9st ide"
},
liststyle:{
armenian:"\xd6rm\xe9ny sz\xe1moz\xe1s",
bulletedTitle:"Pontozott lista tulajdons\xe1gai",
circle:"K\xf6r",
decimal:"Arab sz\xe1moz\xe1s (1, 2, 3, stb.)",
decimalLeadingZero:"Sz\xe1moz\xe1s bevezet\u0151 null\xe1kkal (01, 02, 03, stb.)",
disc:"Korong",
georgian:"Gr\xfaz sz\xe1moz\xe1s (an, ban, gan, stb.)",
lowerAlpha:"Kisbet\u0171s (a, b, c, d, e, stb.)",
lowerGreek:"G\xf6r\xf6g (alpha, beta, gamma, stb.)",
lowerRoman:"R\xf3mai kisbet\u0171s (i, ii, iii, iv, v, stb.)",
none:"Nincs",
notset:"<Nincs be\xe1ll\xedtva>",
numberedTitle:"Sorsz\xe1mozott lista tulajdons\xe1gai",
square:"N\xe9gyzet",
start:"Kezd\u0151sz\xe1m",
type:"T\xedpus",
upperAlpha:"Nagybet\u0171s (A, B, C, D, E, stb.)",
upperRoman:"R\xf3mai nagybet\u0171s (I, II, III, IV, V, stb.)",
validateStartNumber:"A kezd\u0151sz\xe1m nem lehet t\xf6rt \xe9rt\xe9k."
},
list:{
bulletedlist:"Felsorol\xe1s",
numberedlist:"Sz\xe1moz\xe1s"
},
link:{
acccessKey:"Billenty\u0171kombin\xe1ci\xf3",
advanced:"Tov\xe1bbi opci\xf3k",
advisoryContentType:"S\xfag\xf3 tartalomt\xedpusa",
advisoryTitle:"S\xfag\xf3cimke",
anchor:{
toolbar:"Horgony beilleszt\xe9se/szerkeszt\xe9se",
menu:"Horgony tulajdons\xe1gai",
title:"Horgony tulajdons\xe1gai",
name:"Horgony neve",
errorName:"K\xe9rem adja meg a horgony nev\xe9t",
remove:"Horgony elt\xe1vol\xedt\xe1sa"
},
anchorId:"Azonos\xedt\xf3 szerint",
anchorName:"Horgony n\xe9v szerint",
charset:"Hivatkozott tartalom k\xf3dlapja",
cssClasses:"St\xedlusk\xe9szlet",
emailAddress:"E-Mail c\xedm",
emailBody:"\xdczenet",
emailSubject:"\xdczenet t\xe1rgya",
id:"Id",
info:"Alaptulajdons\xe1gok",
langCode:"\xcdr\xe1s ir\xe1nya",
langDir:"\xcdr\xe1s ir\xe1nya",
langDirLTR:"Balr\xf3l jobbra",
langDirRTL:"Jobbr\xf3l balra",
menu:"Hivatkoz\xe1s m\xf3dos\xedt\xe1sa",
name:"N\xe9v",
noAnchors:"(Nincs horgony a dokumentumban)",
noEmail:"Adja meg az E-Mail c\xedmet",
noUrl:"Adja meg a hivatkoz\xe1s webc\xedm\xe9t",
other:"<m\xe1s>",
popupDependent:"Sz\xfcl\u0151h\xf6z kapcsolt (csak Netscape)",
popupFeatures:"Felugr\xf3 ablak jellemz\u0151i",
popupFullScreen:"Teljes k\xe9perny\u0151 (csak IE)",
popupLeft:"Bal poz\xedci\xf3",
popupLocationBar:"C\xedmsor",
popupMenuBar:"Men\xfc sor",
popupResizable:"\xc1tm\xe9retez\xe9s",
popupScrollBars:"G\xf6rd\xedt\u0151s\xe1v",
popupStatusBar:"\xc1llapotsor",
popupToolbar:"Eszk\xf6zt\xe1r",
popupTop:"Fels\u0151 poz\xedci\xf3",
rel:"Kapcsolat t\xedpusa",
selectAnchor:"Horgony v\xe1laszt\xe1sa",
styles:"St\xedlus",
tabIndex:"Tabul\xe1tor index",
target:"Tartalom megjelen\xedt\xe9se",
targetFrame:"<keretben>",
targetFrameName:"Keret neve",
targetPopup:"<felugr\xf3 ablakban>",
targetPopupName:"Felugr\xf3 ablak neve",
title:"Hivatkoz\xe1s tulajdons\xe1gai",
toAnchor:"Horgony az oldalon",
toEmail:"E-Mail",
toUrl:"URL",
toolbar:"Hivatkoz\xe1s beilleszt\xe9se/m\xf3dos\xedt\xe1sa",
type:"Hivatkoz\xe1s t\xedpusa",
unlink:"Hivatkoz\xe1s t\xf6rl\xe9se",
upload:"Felt\xf6lt\xe9s"
},
justify:{
block:"Sorkiz\xe1rt",
center:"K\xf6z\xe9pre",
left:"Balra",
right:"Jobbra"
},
indent:{
indent:"Beh\xfaz\xe1s n\xf6vel\xe9se",
outdent:"Beh\xfaz\xe1s cs\xf6kkent\xe9se"
},
image:{
alertUrl:"T\xf6ltse ki a k\xe9p webc\xedm\xe9t",
alt:"Bubor\xe9k sz\xf6veg",
border:"Keret",
btnUpload:"K\xfcld\xe9s a szerverre",
button2Img:"A kiv\xe1lasztott k\xe9pgombb\xf3l sima k\xe9pet szeretne csin\xe1lni?",
hSpace:"V\xedzsz. t\xe1v",
img2Button:"A kiv\xe1lasztott k\xe9pb\u0151l k\xe9pgombot szeretne csin\xe1lni?",
infoTab:"Alaptulajdons\xe1gok",
linkTab:"Hivatkoz\xe1s",
lockRatio:"Ar\xe1ny megtart\xe1sa",
menu:"K\xe9p tulajdons\xe1gai",
resetSize:"Eredeti m\xe9ret",
title:"K\xe9p tulajdons\xe1gai",
titleButton:"K\xe9pgomb tulajdons\xe1gai",
upload:"Felt\xf6lt\xe9s",
urlMissing:"Hi\xe1nyzik a k\xe9p URL-je",
vSpace:"F\xfcgg. t\xe1v",
validateBorder:"A keret m\xe9ret\xe9nek eg\xe9sz sz\xe1mot kell be\xedrni!",
validateHSpace:"V\xedzszintes t\xe1vols\xe1gnak eg\xe9sz sz\xe1mot kell be\xedrni!",
validateVSpace:"F\xfcgg\u0151leges t\xe1vols\xe1gnak eg\xe9sz sz\xe1mot kell be\xedrni!"
},
iframe:{
border:"Legyen keret",
noUrl:"K\xe9rem \xedrja be a iframe URL-t",
scrolling:"G\xf6rd\xedt\u0151s\xe1v bekapcsol\xe1sa",
title:"IFrame Tulajdons\xe1gok",
toolbar:"IFrame"
},
horizontalrule:{
toolbar:"Elv\xe1laszt\xf3vonal beilleszt\xe9se"
},
forms:{
button:{
title:"Gomb tulajdons\xe1gai",
text:"Sz\xf6veg (\xc9rt\xe9k)",
type:"T\xedpus",
typeBtn:"Gomb",
typeSbm:"K\xfcld\xe9s",
typeRst:"Alaphelyzet"
},
checkboxAndRadio:{
checkboxTitle:"Jel\xf6l\u0151n\xe9gyzet tulajdons\xe1gai",
radioTitle:"V\xe1laszt\xf3gomb tulajdons\xe1gai",
value:"\xc9rt\xe9k",
selected:"Kiv\xe1lasztott"
},
form:{
title:"\u0170rlap tulajdons\xe1gai",
menu:"\u0170rlap tulajdons\xe1gai",
action:"Adatfeldolgoz\xe1st v\xe9gz\u0151 hivatkoz\xe1s",
method:"Adatk\xfcld\xe9s m\xf3dja",
encoding:"K\xf3dol\xe1s"
},
hidden:{
title:"Rejtett mez\u0151 tulajdons\xe1gai",
name:"N\xe9v",
value:"\xc9rt\xe9k"
},
select:{
title:"Leg\xf6rd\xfcl\u0151 lista tulajdons\xe1gai",
selectInfo:"Alaptulajdons\xe1gok",
opAvail:"El\xe9rhet\u0151 opci\xf3k",
value:"\xc9rt\xe9k",
size:"M\xe9ret",
lines:"sor",
chkMulti:"t\xf6bb sor is kiv\xe1laszthat\xf3",
opText:"Sz\xf6veg",
opValue:"\xc9rt\xe9k",
btnAdd:"Hozz\xe1ad",
btnModify:"M\xf3dos\xedt",
btnUp:"Fel",
btnDown:"Le",
btnSetValue:"Legyen az alap\xe9rtelmezett \xe9rt\xe9k",
btnDelete:"T\xf6r\xf6l"
},
textarea:{
title:"Sz\xf6vegter\xfclet tulajdons\xe1gai",
cols:"Karakterek sz\xe1ma egy sorban",
rows:"Sorok sz\xe1ma"
},
textfield:{
title:"Sz\xf6vegmez\u0151 tulajdons\xe1gai",
name:"N\xe9v",
value:"\xc9rt\xe9k",
charWidth:"Megjelen\xedtett karakterek sz\xe1ma",
maxChars:"Maxim\xe1lis karaktersz\xe1m",
type:"T\xedpus",
typeText:"Sz\xf6veg",
typePass:"Jelsz\xf3",
typeEmail:"\xcdm\xe9l",
typeSearch:"Keres\xe9s",
typeTel:"Telefonsz\xe1m",
typeUrl:"URL"
}
},
format:{
label:"Form\xe1tum",
panelTitle:"Form\xe1tum",
tag_address:"C\xedmsor",
tag_div:"Bekezd\xe9s (DIV)",
tag_h1:"Fejl\xe9c 1",
tag_h2:"Fejl\xe9c 2",
tag_h3:"Fejl\xe9c 3",
tag_h4:"Fejl\xe9c 4",
tag_h5:"Fejl\xe9c 5",
tag_h6:"Fejl\xe9c 6",
tag_p:"Norm\xe1l",
tag_pre:"Form\xe1zott"
},
font:{
fontSize:{
label:"M\xe9ret",
voiceLabel:"Bet\u0171m\xe9ret",
panelTitle:"M\xe9ret"
},
label:"Bet\u0171t\xedpus",
panelTitle:"Bet\u0171t\xedpus",
voiceLabel:"Bet\u0171t\xedpus"
},
flash:{
access:"Szkript hozz\xe1f\xe9r\xe9s",
accessAlways:"Mindig",
accessNever:"Soha",
accessSameDomain:"Azonos domainr\u0151l",
alignAbsBottom:"Legalj\xe1ra",
alignAbsMiddle:"K\xf6zep\xe9re",
alignBaseline:"Alapvonalhoz",
alignTextTop:"Sz\xf6veg tetej\xe9re",
bgcolor:"H\xe1tt\xe9rsz\xedn",
chkFull:"Teljes k\xe9perny\u0151 enged\xe9lyez\xe9se",
chkLoop:"Folyamatosan",
chkMenu:"Flash men\xfc enged\xe9lyez\xe9se",
chkPlay:"Automata lej\xe1tsz\xe1s",
flashvars:"Flash v\xe1ltoz\xf3k",
hSpace:"V\xedzsz. t\xe1v",
properties:"Flash tulajdons\xe1gai",
propertiesTab:"Tulajdons\xe1gok",
quality:"Min\u0151s\xe9g",
qualityAutoHigh:"Automata j\xf3",
qualityAutoLow:"Automata gyenge",
qualityBest:"Legjobb",
qualityHigh:"J\xf3",
qualityLow:"Gyenge",
qualityMedium:"K\xf6zepes",
scale:"M\xe9retez\xe9s",
scaleAll:"Mindent mutat",
scaleFit:"Teljes kit\xf6lt\xe9s",
scaleNoBorder:"Keret n\xe9lk\xfcl",
title:"Flash tulajdons\xe1gai",
vSpace:"F\xfcgg. t\xe1v",
validateHSpace:"A v\xedzszintes t\xe1vols\u0171\xe1g mez\u0151be csak sz\xe1mokat \xedrhat.",
validateSrc:"Adja meg a hivatkoz\xe1s webc\xedm\xe9t",
validateVSpace:"A f\xfcgg\u0151leges t\xe1vols\u0171\xe1g mez\u0151be csak sz\xe1mokat \xedrhat.",
windowMode:"Ablak m\xf3d",
windowModeOpaque:"Opaque",
windowModeTransparent:"Transparent",
windowModeWindow:"Window"
},
find:{
find:"Keres\xe9s",
findOptions:"Find Options",
findWhat:"Keresett sz\xf6veg:",
matchCase:"kis- \xe9s nagybet\u0171 megk\xfcl\xf6nb\xf6ztet\xe9se",
matchCyclic:"Ciklikus keres\xe9s",
matchWord:"csak ha ez a teljes sz\xf3",
notFoundMsg:"A keresett sz\xf6veg nem tal\xe1lhat\xf3.",
replace:"Csere",
replaceAll:"Az \xf6sszes cser\xe9je",
replaceSuccessMsg:"%1 egyez\u0151s\xe9g cser\xe9lve.",
replaceWith:"Csere erre:",
title:"Keres\xe9s \xe9s csere"
},
fakeobjects:{
anchor:"Horgony",
flash:"Flash anim\xe1ci\xf3",
hiddenfield:"Rejtett mez\xf5",
iframe:"IFrame",
unknown:"Ismeretlen objektum"
},
elementspath:{
eleLabel:"Elem utak",
eleTitle:"%1 elem"
},
div:{
IdInputLabel:"Azonos\xedt\xf3",
advisoryTitleInputLabel:"Tipp sz\xf6veg",
cssClassInputLabel:"St\xedluslap oszt\xe1ly",
edit:"DIV szerkeszt\xe9se",
inlineStyleInputLabel:"Inline st\xedlus",
langDirLTRLabel:"Balr\xf3l jobbra (LTR)",
langDirLabel:"Nyelvi ir\xe1ny",
langDirRTLLabel:"Jobbr\xf3l balra (RTL)",
languageCodeInputLabel:" Nyelv k\xf3dja",
remove:"DIV elt\xe1vol\xedt\xe1sa",
styleSelectLabel:"St\xedlus",
title:"DIV t\xe1rol\xf3 l\xe9trehoz\xe1sa",
toolbar:"DIV t\xe1rol\xf3 l\xe9trehoz\xe1sa"
},
contextmenu:{
options:"Helyi men\xfc opci\xf3k"
},
clipboard:{
copy:"M\xe1sol\xe1s",
copyError:"A b\xf6ng\xe9sz\u0151 biztons\xe1gi be\xe1ll\xedt\xe1sai nem enged\xe9lyezik a szerkeszt\u0151nek, hogy v\xe9grehajtsa a m\xe1sol\xe1s m\u0171veletet. Haszn\xe1lja az al\xe1bbi billenty\u0171kombin\xe1ci\xf3t (Ctrl/Cmd+X).",
cut:"Kiv\xe1g\xe1s",
cutError:"A b\xf6ng\xe9sz\u0151 biztons\xe1gi be\xe1ll\xedt\xe1sai nem enged\xe9lyezik a szerkeszt\u0151nek, hogy v\xe9grehajtsa a kiv\xe1g\xe1s m\u0171veletet. Haszn\xe1lja az al\xe1bbi billenty\u0171kombin\xe1ci\xf3t (Ctrl/Cmd+X).",
paste:"Beilleszt\xe9s",
pasteArea:"Besz\xfar\xe1s mez\u0151",
pasteMsg:"M\xe1solja be az al\xe1bbi mez\u0151be a <STRONG>Ctrl/Cmd+V</STRONG> billenty\u0171k lenyom\xe1s\xe1val, majd nyomjon <STRONG>Rendben</STRONG>-t.",
securityMsg:"A b\xf6ng\xe9sz\u0151 biztons\xe1gi be\xe1ll\xedt\xe1sai miatt a szerkeszt\u0151 nem k\xe9pes hozz\xe1f\xe9rni a v\xe1g\xf3lap adataihoz. Illeszd be \xfajra ebben az ablakban.",
title:"Beilleszt\xe9s"
},
button:{
selectedLabel:"%1 (Selected)"
},
blockquote:{
toolbar:"Id\xe9zet blokk"
},
basicstyles:{
bold:"F\xe9lk\xf6v\xe9r",
italic:"D\u0151lt",
strike:"\xc1th\xfazott",
subscript:"Als\xf3 index",
superscript:"Fels\u0151 index",
underline:"Al\xe1h\xfazott"
},
about:{
copy:"Copyright &copy; $1. Minden jog fenntartva.",
dlgTitle:"CKEditor n\xe9vjegy",
help:"Itt tal\xe1lsz seg\xedts\xe9get: $1",
moreInfo:"Licenszel\xe9si inform\xe1ci\xf3k\xe9rt k\xe9rj\xfck l\xe1togassa meg weboldalunkat:",
title:"CKEditor n\xe9vjegy",
userGuide:"CKEditor Felhaszn\xe1l\xf3i \xfatmutat\xf3"
},
editor:"HTML szerkeszt\u0151",
editorPanel:"Rich Text szerkeszt\u0151 panel",
common:{
editorHelp:"Seg\xedts\xe9g\xe9rt nyomjon ALT 0",
browseServer:"B\xf6ng\xe9sz\xe9s a szerveren",
url:"Hivatkoz\xe1s",
protocol:"Protokoll",
upload:"Felt\xf6lt\xe9s",
uploadSubmit:"K\xfcld\xe9s a szerverre",
image:"K\xe9p",
flash:"Flash",
form:"\u0170rlap",
checkbox:"Jel\xf6l\u0151n\xe9gyzet",
radio:"V\xe1laszt\xf3gomb",
textField:"Sz\xf6vegmez\u0151",
textarea:"Sz\xf6vegter\xfclet",
hiddenField:"Rejtettmez\u0151",
button:"Gomb",
select:"Leg\xf6rd\xfcl\u0151 lista",
imageButton:"K\xe9pgomb",
notSet:"<nincs be\xe1ll\xedtva>",
id:"Azonos\xedt\xf3",
name:"N\xe9v",
langDir:"\xcdr\xe1s ir\xe1nya",
langDirLtr:"Balr\xf3l jobbra",
langDirRtl:"Jobbr\xf3l balra",
langCode:"Nyelv k\xf3dja",
longDescr:"R\xe9szletes le\xedr\xe1s webc\xedme",
cssClass:"St\xedlusk\xe9szlet",
advisoryTitle:"S\xfag\xf3cimke",
cssStyle:"St\xedlus",
ok:"Rendben",
cancel:"M\xe9gsem",
close:"Bez\xe1r\xe1s",
preview:"El\u0151n\xe9zet",
resize:"H\xfazza az \xe1tm\xe9retez\xe9shez",
generalTab:"\xc1ltal\xe1nos",
advancedTab:"Tov\xe1bbi opci\xf3k",
validateNumberFailed:"A mez\u0151be csak sz\xe1mokat \xedrhat.",
confirmNewPage:"Minden nem mentett v\xe1ltoz\xe1s el fog veszni! Biztosan be szeretn\xe9 t\xf6lteni az oldalt?",
confirmCancel:"Az \u0171rlap tartalma megv\xe1ltozott, \xe1m a v\xe1ltoz\xe1sokat nem r\xf6gz\xedtette. Biztosan be szeretn\xe9 z\xe1rni az \u0171rlapot?",
options:"Be\xe1ll\xedt\xe1sok",
target:"C\xe9l",
targetNew:"\xdaj ablak (_blank)",
targetTop:"Legfels\u0151 ablak (_top)",
targetSelf:"Aktu\xe1lis ablakban (_self)",
targetParent:"Sz\xfcl\u0151 ablak (_parent)",
langDirLTR:"Balr\xf3l jobbra (LTR)",
langDirRTL:"Jobbr\xf3l balra (RTL)",
styles:"St\xedlus",
cssClasses:"St\xedluslap oszt\xe1ly",
width:"Sz\xe9less\xe9g",
height:"Magass\xe1g",
align:"Igaz\xedt\xe1s",
alignLeft:"Bal",
alignRight:"Jobbra",
alignCenter:"K\xf6z\xe9pre",
alignTop:"Tetej\xe9re",
alignMiddle:"K\xf6z\xe9pre",
alignBottom:"Alj\xe1ra",
invalidValue:"\xc9rv\xe9nytelen \xe9rt\xe9k.",
invalidHeight:"A magass\xe1g mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidWidth:"A sz\xe9less\xe9g mez\u0151be csak sz\xe1mokat \xedrhat.",
invalidCssLength:'"%1"-hez megadott \xe9rt\xe9k csakis egy pozit\xedv sz\xe1m lehet, esetleg egy \xe9rv\xe9nyes CSS egys\xe9ggel megjel\xf6lve(px, %, in, cm, mm, em, ex, pt vagy pc).',
invalidHtmlLength:'"%1"-hez megadott \xe9rt\xe9k csakis egy pozit\xedv sz\xe1m lehet, esetleg egy \xe9rv\xe9nyes HTML egys\xe9ggel megjel\xf6lve(px vagy %).',
invalidInlineStyle:'Az inline st\xedlusnak megadott \xe9rt\xe9knek tartalmaznia kell egy vagy t\xf6bb rekordot a "name : value" form\xe1tumban, pontosvessz\u0151vel elv\xe1lasztva.',
cssLengthTooltip:"Adjon meg egy sz\xe1mot \xe9rt\xe9knek pixelekben vagy egy sz\xe1mot \xe9rv\xe9nyes CSS m\xe9rt\xe9kegys\xe9gben (px, %, in, cm, mm, em, ex, pt, vagy pc).",
unavailable:'%1<span class="cke_accessibility">, nem el\xe9rhet\u0151</span>'
}
};