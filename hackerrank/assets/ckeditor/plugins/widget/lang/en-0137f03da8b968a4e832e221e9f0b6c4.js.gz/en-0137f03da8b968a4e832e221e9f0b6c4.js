/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","en",{move:"Click and drag to move"});
//# sourceMappingURL=en-677b26cf64d2fde19ce0f7f94c4aeaf7.js.map