var _requirejs = requirejs; requirejs = undefined; var _require = require; require = undefined; var _define = define; define = undefined; 
// CodeMirror, copyright (c) by Marijn Haverbeke and others
!function(){function r(r){test.mode(r,e,Array.prototype.slice.call(arguments,1))}var e=CodeMirror.getMode({indentUnit:2},"ruby");r("divide_equal_operator","[variable bar] [operator /=] [variable foo]"),r("divide_equal_operator_no_spacing","[variable foo][operator /=][number 42]")}();
//# sourceMappingURL=test-e7b13bb0f26da531351d3168635005a2.js.map
var requirejs = _requirejs; _requirejs = undefined; var require = _require; _require = undefined; var define = _define; _define = undefined; 