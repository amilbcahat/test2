CodeMirror.defineMode("toml", function() {
return {
startState:function() {
return {
inString:!1,
stringType:"",
lhs:!0,
inArray:0
};
},
token:function(stream, state) {
if (state.inString || '"' != stream.peek() && "'" != stream.peek() || (state.stringType = stream.peek(), 
stream.next(), state.inString = !0), stream.sol() && 0 === state.inArray && (state.lhs = !0), 
state.inString) {
for (;state.inString && !stream.eol(); ) stream.peek() === state.stringType ? (stream.next(), 
state.inString = !1) :"\\" === stream.peek() ? (stream.next(), stream.next()) :stream.match(/^.[^\\\"\']*/);
return state.lhs ? "property string" :"string";
}
return state.inArray && "]" === stream.peek() ? (stream.next(), state.inArray--, 
"bracket") :state.lhs && "[" === stream.peek() && stream.skipTo("]") ? (stream.next(), 
"atom") :"#" === stream.peek() ? (stream.skipToEnd(), "comment") :stream.eatSpace() ? null :state.lhs && stream.eatWhile(function(c) {
return "=" != c && " " != c;
}) ? "property" :state.lhs && "=" === stream.peek() ? (stream.next(), state.lhs = !1, 
null) :!state.lhs && stream.match(/^\d\d\d\d[\d\-\:\.T]*Z/) ? "atom" :state.lhs || !stream.match("true") && !stream.match("false") ? state.lhs || "[" !== stream.peek() ? !state.lhs && stream.match(/^\-?\d+(?:\.\d+)?/) ? "number" :(stream.eatSpace() || stream.next(), 
null) :(state.inArray++, stream.next(), "bracket") :"atom";
}
};
}), CodeMirror.defineMIME("text/x-toml", "toml");