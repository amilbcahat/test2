// Copyright 2006 Google Inc.
document.createElement("canvas").getContext || !function() {
function getContext() {
return this.context_ || (this.context_ = new CanvasRenderingContext2D_(this));
}
function bind(f, obj) {
var a = slice.call(arguments, 2);
return function() {
return f.apply(obj, a.concat(slice.call(arguments)));
};
}
function onPropertyChange(e) {
var el = e.srcElement;
switch (e.propertyName) {
case "width":
el.style.width = el.attributes.width.nodeValue + "px", el.getContext().clearRect();
break;

case "height":
el.style.height = el.attributes.height.nodeValue + "px", el.getContext().clearRect();
}
}
function onResize(e) {
var el = e.srcElement;
el.firstChild && (el.firstChild.style.width = el.clientWidth + "px", el.firstChild.style.height = el.clientHeight + "px");
}
function createMatrixIdentity() {
return [ [ 1, 0, 0 ], [ 0, 1, 0 ], [ 0, 0, 1 ] ];
}
function matrixMultiply(m1, m2) {
for (var result = createMatrixIdentity(), x = 0; 3 > x; x++) for (var y = 0; 3 > y; y++) {
for (var sum = 0, z = 0; 3 > z; z++) sum += m1[x][z] * m2[z][y];
result[x][y] = sum;
}
return result;
}
function copyState(o1, o2) {
o2.fillStyle = o1.fillStyle, o2.lineCap = o1.lineCap, o2.lineJoin = o1.lineJoin, 
o2.lineWidth = o1.lineWidth, o2.miterLimit = o1.miterLimit, o2.shadowBlur = o1.shadowBlur, 
o2.shadowColor = o1.shadowColor, o2.shadowOffsetX = o1.shadowOffsetX, o2.shadowOffsetY = o1.shadowOffsetY, 
o2.strokeStyle = o1.strokeStyle, o2.globalAlpha = o1.globalAlpha, o2.arcScaleX_ = o1.arcScaleX_, 
o2.arcScaleY_ = o1.arcScaleY_, o2.lineScale_ = o1.lineScale_;
}
function processStyle(styleString) {
var str, alpha = 1;
if (styleString = String(styleString), "rgb" == styleString.substring(0, 3)) {
var start = styleString.indexOf("(", 3), end = styleString.indexOf(")", start + 1), guts = styleString.substring(start + 1, end).split(",");
str = "#";
for (var i = 0; 3 > i; i++) str += dec2hex[Number(guts[i])];
4 == guts.length && "a" == styleString.substr(3, 1) && (alpha = guts[3]);
} else str = styleString;
return {
color:str,
alpha:alpha
};
}
function processLineCap(lineCap) {
switch (lineCap) {
case "butt":
return "flat";

case "round":
return "round";

case "square":
default:
return "square";
}
}
function CanvasRenderingContext2D_(surfaceElement) {
this.m_ = createMatrixIdentity(), this.mStack_ = [], this.aStack_ = [], this.currentPath_ = [], 
this.strokeStyle = "#000", this.fillStyle = "#000", this.lineWidth = 1, this.lineJoin = "miter", 
this.lineCap = "butt", this.miterLimit = 1 * Z, this.globalAlpha = 1, this.canvas = surfaceElement;
var el = surfaceElement.ownerDocument.createElement("div");
el.style.width = surfaceElement.clientWidth + "px", el.style.height = surfaceElement.clientHeight + "px", 
el.style.overflow = "hidden", el.style.position = "absolute", surfaceElement.appendChild(el), 
this.element_ = el, this.arcScaleX_ = 1, this.arcScaleY_ = 1, this.lineScale_ = 1;
}
function bezierCurveTo(self, cp1, cp2, p) {
self.currentPath_.push({
type:"bezierCurveTo",
cp1x:cp1.x,
cp1y:cp1.y,
cp2x:cp2.x,
cp2y:cp2.y,
x:p.x,
y:p.y
}), self.currentX_ = p.x, self.currentY_ = p.y;
}
function matrixIsFinite(m) {
for (var j = 0; 3 > j; j++) for (var k = 0; 2 > k; k++) if (!isFinite(m[j][k]) || isNaN(m[j][k])) return !1;
return !0;
}
function setM(ctx, m, updateLineScale) {
if (matrixIsFinite(m) && (ctx.m_ = m, updateLineScale)) {
var det = m[0][0] * m[1][1] - m[0][1] * m[1][0];
ctx.lineScale_ = sqrt(abs(det));
}
}
function CanvasGradient_(aType) {
this.type_ = aType, this.x0_ = 0, this.y0_ = 0, this.r0_ = 0, this.x1_ = 0, this.y1_ = 0, 
this.r1_ = 0, this.colors_ = [];
}
function CanvasPattern_() {}
var m = Math, mr = m.round, ms = m.sin, mc = m.cos, abs = m.abs, sqrt = m.sqrt, Z = 10, Z2 = Z / 2, slice = Array.prototype.slice, G_vmlCanvasManager_ = {
init:function(opt_doc) {
if (/MSIE/.test(navigator.userAgent) && !window.opera) {
var doc = opt_doc || document;
doc.createElement("canvas"), doc.attachEvent("onreadystatechange", bind(this.init_, this, doc));
}
},
init_:function(doc) {
if (doc.namespaces.g_vml_ || doc.namespaces.add("g_vml_", "urn:schemas-microsoft-com:vml", "#default#VML"), 
doc.namespaces.g_o_ || doc.namespaces.add("g_o_", "urn:schemas-microsoft-com:office:office", "#default#VML"), 
!doc.styleSheets.ex_canvas_) {
var ss = doc.createStyleSheet();
ss.owningElement.id = "ex_canvas_", ss.cssText = "canvas{display:inline-block;overflow:hidden;text-align:left;width:300px;height:150px}g_vml_\\:*{behavior:url(#default#VML)}g_o_\\:*{behavior:url(#default#VML)}";
}
for (var els = doc.getElementsByTagName("canvas"), i = 0; i < els.length; i++) this.initElement(els[i]);
},
initElement:function(el) {
if (!el.getContext) {
el.getContext = getContext, el.innerHTML = "", el.attachEvent("onpropertychange", onPropertyChange), 
el.attachEvent("onresize", onResize);
var attrs = el.attributes;
attrs.width && attrs.width.specified ? el.style.width = attrs.width.nodeValue + "px" :el.width = el.clientWidth, 
attrs.height && attrs.height.specified ? el.style.height = attrs.height.nodeValue + "px" :el.height = el.clientHeight;
}
return el;
}
};
G_vmlCanvasManager_.init();
for (var dec2hex = [], i = 0; 16 > i; i++) for (var j = 0; 16 > j; j++) dec2hex[16 * i + j] = i.toString(16) + j.toString(16);
var contextPrototype = CanvasRenderingContext2D_.prototype;
contextPrototype.clearRect = function() {
this.element_.innerHTML = "";
}, contextPrototype.beginPath = function() {
this.currentPath_ = [];
}, contextPrototype.moveTo = function(aX, aY) {
var p = this.getCoords_(aX, aY);
this.currentPath_.push({
type:"moveTo",
x:p.x,
y:p.y
}), this.currentX_ = p.x, this.currentY_ = p.y;
}, contextPrototype.lineTo = function(aX, aY) {
var p = this.getCoords_(aX, aY);
this.currentPath_.push({
type:"lineTo",
x:p.x,
y:p.y
}), this.currentX_ = p.x, this.currentY_ = p.y;
}, contextPrototype.bezierCurveTo = function(aCP1x, aCP1y, aCP2x, aCP2y, aX, aY) {
var p = this.getCoords_(aX, aY), cp1 = this.getCoords_(aCP1x, aCP1y), cp2 = this.getCoords_(aCP2x, aCP2y);
bezierCurveTo(this, cp1, cp2, p);
}, contextPrototype.quadraticCurveTo = function(aCPx, aCPy, aX, aY) {
var cp = this.getCoords_(aCPx, aCPy), p = this.getCoords_(aX, aY), cp1 = {
x:this.currentX_ + 2 / 3 * (cp.x - this.currentX_),
y:this.currentY_ + 2 / 3 * (cp.y - this.currentY_)
}, cp2 = {
x:cp1.x + (p.x - this.currentX_) / 3,
y:cp1.y + (p.y - this.currentY_) / 3
};
bezierCurveTo(this, cp1, cp2, p);
}, contextPrototype.arc = function(aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise) {
aRadius *= Z;
var arcType = aClockwise ? "at" :"wa", xStart = aX + mc(aStartAngle) * aRadius - Z2, yStart = aY + ms(aStartAngle) * aRadius - Z2, xEnd = aX + mc(aEndAngle) * aRadius - Z2, yEnd = aY + ms(aEndAngle) * aRadius - Z2;
xStart != xEnd || aClockwise || (xStart += .125);
var p = this.getCoords_(aX, aY), pStart = this.getCoords_(xStart, yStart), pEnd = this.getCoords_(xEnd, yEnd);
this.currentPath_.push({
type:arcType,
x:p.x,
y:p.y,
radius:aRadius,
xStart:pStart.x,
yStart:pStart.y,
xEnd:pEnd.x,
yEnd:pEnd.y
});
}, contextPrototype.rect = function(aX, aY, aWidth, aHeight) {
this.moveTo(aX, aY), this.lineTo(aX + aWidth, aY), this.lineTo(aX + aWidth, aY + aHeight), 
this.lineTo(aX, aY + aHeight), this.closePath();
}, contextPrototype.strokeRect = function(aX, aY, aWidth, aHeight) {
var oldPath = this.currentPath_;
this.beginPath(), this.moveTo(aX, aY), this.lineTo(aX + aWidth, aY), this.lineTo(aX + aWidth, aY + aHeight), 
this.lineTo(aX, aY + aHeight), this.closePath(), this.stroke(), this.currentPath_ = oldPath;
}, contextPrototype.fillRect = function(aX, aY, aWidth, aHeight) {
var oldPath = this.currentPath_;
this.beginPath(), this.moveTo(aX, aY), this.lineTo(aX + aWidth, aY), this.lineTo(aX + aWidth, aY + aHeight), 
this.lineTo(aX, aY + aHeight), this.closePath(), this.fill(), this.currentPath_ = oldPath;
}, contextPrototype.createLinearGradient = function(aX0, aY0, aX1, aY1) {
var gradient = new CanvasGradient_("gradient");
return gradient.x0_ = aX0, gradient.y0_ = aY0, gradient.x1_ = aX1, gradient.y1_ = aY1, 
gradient;
}, contextPrototype.createRadialGradient = function(aX0, aY0, aR0, aX1, aY1, aR1) {
var gradient = new CanvasGradient_("gradientradial");
return gradient.x0_ = aX0, gradient.y0_ = aY0, gradient.r0_ = aR0, gradient.x1_ = aX1, 
gradient.y1_ = aY1, gradient.r1_ = aR1, gradient;
}, contextPrototype.drawImage = function(image) {
var dx, dy, dw, dh, sx, sy, sw, sh, oldRuntimeWidth = image.runtimeStyle.width, oldRuntimeHeight = image.runtimeStyle.height;
image.runtimeStyle.width = "auto", image.runtimeStyle.height = "auto";
var w = image.width, h = image.height;
if (image.runtimeStyle.width = oldRuntimeWidth, image.runtimeStyle.height = oldRuntimeHeight, 
3 == arguments.length) dx = arguments[1], dy = arguments[2], sx = sy = 0, sw = dw = w, 
sh = dh = h; else if (5 == arguments.length) dx = arguments[1], dy = arguments[2], 
dw = arguments[3], dh = arguments[4], sx = sy = 0, sw = w, sh = h; else {
if (9 != arguments.length) throw Error("Invalid number of arguments");
sx = arguments[1], sy = arguments[2], sw = arguments[3], sh = arguments[4], dx = arguments[5], 
dy = arguments[6], dw = arguments[7], dh = arguments[8];
}
var d = this.getCoords_(dx, dy), vmlStr = [], W = 10, H = 10;
if (vmlStr.push(" <g_vml_:group", ' coordsize="', Z * W, ",", Z * H, '"', ' coordorigin="0,0"', ' style="width:', W, "px;height:", H, "px;position:absolute;"), 
1 != this.m_[0][0] || this.m_[0][1]) {
var filter = [];
filter.push("M11=", this.m_[0][0], ",", "M12=", this.m_[1][0], ",", "M21=", this.m_[0][1], ",", "M22=", this.m_[1][1], ",", "Dx=", mr(d.x / Z), ",", "Dy=", mr(d.y / Z), "");
var max = d, c2 = this.getCoords_(dx + dw, dy), c3 = this.getCoords_(dx, dy + dh), c4 = this.getCoords_(dx + dw, dy + dh);
max.x = m.max(max.x, c2.x, c3.x, c4.x), max.y = m.max(max.y, c2.y, c3.y, c4.y), 
vmlStr.push("padding:0 ", mr(max.x / Z), "px ", mr(max.y / Z), "px 0;filter:progid:DXImageTransform.Microsoft.Matrix(", filter.join(""), ", sizingmethod='clip');");
} else vmlStr.push("top:", mr(d.y / Z), "px;left:", mr(d.x / Z), "px;");
vmlStr.push(' ">', '<g_vml_:image src="', image.src, '"', ' style="width:', Z * dw, "px;", " height:", Z * dh, 'px;"', ' cropleft="', sx / w, '"', ' croptop="', sy / h, '"', ' cropright="', (w - sx - sw) / w, '"', ' cropbottom="', (h - sy - sh) / h, '"', " />", "</g_vml_:group>"), 
this.element_.insertAdjacentHTML("BeforeEnd", vmlStr.join(""));
}, contextPrototype.stroke = function(aFill) {
var lineStr = [], a = processStyle(aFill ? this.fillStyle :this.strokeStyle), color = a.color, opacity = a.alpha * this.globalAlpha, W = 10, H = 10;
lineStr.push("<g_vml_:shape", ' filled="', !!aFill, '"', ' style="position:absolute;width:', W, "px;height:", H, 'px;"', ' coordorigin="0 0" coordsize="', Z * W, " ", Z * H, '"', ' stroked="', !aFill, '"', ' path="');
for (var min = {
x:null,
y:null
}, max = {
x:null,
y:null
}, i = 0; i < this.currentPath_.length; i++) {
var c, p = this.currentPath_[i];
switch (p.type) {
case "moveTo":
c = p, lineStr.push(" m ", mr(p.x), ",", mr(p.y));
break;

case "lineTo":
lineStr.push(" l ", mr(p.x), ",", mr(p.y));
break;

case "close":
lineStr.push(" x "), p = null;
break;

case "bezierCurveTo":
lineStr.push(" c ", mr(p.cp1x), ",", mr(p.cp1y), ",", mr(p.cp2x), ",", mr(p.cp2y), ",", mr(p.x), ",", mr(p.y));
break;

case "at":
case "wa":
lineStr.push(" ", p.type, " ", mr(p.x - this.arcScaleX_ * p.radius), ",", mr(p.y - this.arcScaleY_ * p.radius), " ", mr(p.x + this.arcScaleX_ * p.radius), ",", mr(p.y + this.arcScaleY_ * p.radius), " ", mr(p.xStart), ",", mr(p.yStart), " ", mr(p.xEnd), ",", mr(p.yEnd));
}
p && ((null == min.x || p.x < min.x) && (min.x = p.x), (null == max.x || p.x > max.x) && (max.x = p.x), 
(null == min.y || p.y < min.y) && (min.y = p.y), (null == max.y || p.y > max.y) && (max.y = p.y));
}
if (lineStr.push(' ">'), aFill) if ("object" == typeof this.fillStyle) {
var fillStyle = this.fillStyle, angle = 0, focus = {
x:0,
y:0
}, shift = 0, expansion = 1;
if ("gradient" == fillStyle.type_) {
var x0 = fillStyle.x0_ / this.arcScaleX_, y0 = fillStyle.y0_ / this.arcScaleY_, x1 = fillStyle.x1_ / this.arcScaleX_, y1 = fillStyle.y1_ / this.arcScaleY_, p0 = this.getCoords_(x0, y0), p1 = this.getCoords_(x1, y1), dx = p1.x - p0.x, dy = p1.y - p0.y;
angle = 180 * Math.atan2(dx, dy) / Math.PI, 0 > angle && (angle += 360), 1e-6 > angle && (angle = 0);
} else {
var p0 = this.getCoords_(fillStyle.x0_, fillStyle.y0_), width = max.x - min.x, height = max.y - min.y;
focus = {
x:(p0.x - min.x) / width,
y:(p0.y - min.y) / height
}, width /= this.arcScaleX_ * Z, height /= this.arcScaleY_ * Z;
var dimension = m.max(width, height);
shift = 2 * fillStyle.r0_ / dimension, expansion = 2 * fillStyle.r1_ / dimension - shift;
}
var stops = fillStyle.colors_;
stops.sort(function(cs1, cs2) {
return cs1.offset - cs2.offset;
});
for (var length = stops.length, color1 = stops[0].color, color2 = stops[length - 1].color, opacity1 = stops[0].alpha * this.globalAlpha, opacity2 = stops[length - 1].alpha * this.globalAlpha, colors = [], i = 0; length > i; i++) {
var stop = stops[i];
colors.push(stop.offset * expansion + shift + " " + stop.color);
}
lineStr.push('<g_vml_:fill type="', fillStyle.type_, '"', ' method="none" focus="100%"', ' color="', color1, '"', ' color2="', color2, '"', ' colors="', colors.join(","), '"', ' opacity="', opacity2, '"', ' g_o_:opacity2="', opacity1, '"', ' angle="', angle, '"', ' focusposition="', focus.x, ",", focus.y, '" />');
} else lineStr.push('<g_vml_:fill color="', color, '" opacity="', opacity, '" />'); else {
var lineWidth = this.lineScale_ * this.lineWidth;
1 > lineWidth && (opacity *= lineWidth), lineStr.push("<g_vml_:stroke", ' opacity="', opacity, '"', ' joinstyle="', this.lineJoin, '"', ' miterlimit="', this.miterLimit, '"', ' endcap="', processLineCap(this.lineCap), '"', ' weight="', lineWidth, 'px"', ' color="', color, '" />');
}
lineStr.push("</g_vml_:shape>"), this.element_.insertAdjacentHTML("beforeEnd", lineStr.join(""));
}, contextPrototype.fill = function() {
this.stroke(!0);
}, contextPrototype.closePath = function() {
this.currentPath_.push({
type:"close"
});
}, contextPrototype.getCoords_ = function(aX, aY) {
var m = this.m_;
return {
x:Z * (aX * m[0][0] + aY * m[1][0] + m[2][0]) - Z2,
y:Z * (aX * m[0][1] + aY * m[1][1] + m[2][1]) - Z2
};
}, contextPrototype.save = function() {
var o = {};
copyState(this, o), this.aStack_.push(o), this.mStack_.push(this.m_), this.m_ = matrixMultiply(createMatrixIdentity(), this.m_);
}, contextPrototype.restore = function() {
copyState(this.aStack_.pop(), this), this.m_ = this.mStack_.pop();
}, contextPrototype.translate = function(aX, aY) {
var m1 = [ [ 1, 0, 0 ], [ 0, 1, 0 ], [ aX, aY, 1 ] ];
setM(this, matrixMultiply(m1, this.m_), !1);
}, contextPrototype.rotate = function(aRot) {
var c = mc(aRot), s = ms(aRot), m1 = [ [ c, s, 0 ], [ -s, c, 0 ], [ 0, 0, 1 ] ];
setM(this, matrixMultiply(m1, this.m_), !1);
}, contextPrototype.scale = function(aX, aY) {
this.arcScaleX_ *= aX, this.arcScaleY_ *= aY;
var m1 = [ [ aX, 0, 0 ], [ 0, aY, 0 ], [ 0, 0, 1 ] ];
setM(this, matrixMultiply(m1, this.m_), !0);
}, contextPrototype.transform = function(m11, m12, m21, m22, dx, dy) {
var m1 = [ [ m11, m12, 0 ], [ m21, m22, 0 ], [ dx, dy, 1 ] ];
setM(this, matrixMultiply(m1, this.m_), !0);
}, contextPrototype.setTransform = function(m11, m12, m21, m22, dx, dy) {
var m = [ [ m11, m12, 0 ], [ m21, m22, 0 ], [ dx, dy, 1 ] ];
setM(this, m, !0);
}, contextPrototype.clip = function() {}, contextPrototype.arcTo = function() {}, 
contextPrototype.createPattern = function() {
return new CanvasPattern_();
}, CanvasGradient_.prototype.addColorStop = function(aOffset, aColor) {
aColor = processStyle(aColor), this.colors_.push({
offset:aOffset,
color:aColor.color,
alpha:aColor.alpha
});
}, G_vmlCanvasManager = G_vmlCanvasManager_, CanvasRenderingContext2D = CanvasRenderingContext2D_, 
CanvasGradient = CanvasGradient_, CanvasPattern = CanvasPattern_;
}();