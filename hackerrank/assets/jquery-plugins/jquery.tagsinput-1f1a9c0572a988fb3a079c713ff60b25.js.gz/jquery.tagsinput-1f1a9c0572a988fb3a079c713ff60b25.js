/*
  Forked Version of
  jQuery Tags Input Plugin 1.3.3

  Copyright (c) 2011 XOXCO, Inc

  Documentation for this plugin lives here:
  **NEVER UPGRADE**
  http://xoxco.com/clickable/jquery-tags-input
  **NEVER UPGRADE**

  Licensed under the MIT license:
  http://www.opensource.org/licenses/mit-license.php

  forked by: shiv@hackerrank.com
  author: ben@xoxco.com
*/
!function($) {
var delimiter = new Array(), tags_callbacks = new Array();
$.fn.doAutosize = function(o) {
var minWidth = $(this).data("minwidth"), maxWidth = $(this).data("maxwidth"), val = "", input = $(this), testSubject = $("#" + $(this).data("tester_id"));
if (val !== (val = input.val())) {
var escaped = val.replace(/&/g, "&amp;").replace(/\s/g, " ").replace(/</g, "&lt;").replace(/>/g, "&gt;");
testSubject.html(escaped);
var testerWidth = testSubject.width(), newWidth = testerWidth + o.comfortZone >= minWidth ? testerWidth + o.comfortZone :minWidth, currentWidth = input.width(), isValidWidthChange = currentWidth > newWidth && newWidth >= minWidth || newWidth > minWidth && maxWidth > newWidth;
isValidWidthChange && input.width(newWidth);
}
}, $.fn.resetAutosize = function(options) {
var minWidth = $(this).data("minwidth") || options.minInputWidth || $(this).width(), maxWidth = $(this).data("maxwidth") || options.maxInputWidth || $(this).closest(".tagsinput").width() - options.inputPadding, input = $(this), testSubject = $("<tester/>").css({
position:"absolute",
top:-9999,
left:-9999,
width:"auto",
fontSize:input.css("fontSize"),
fontFamily:input.css("fontFamily"),
fontWeight:input.css("fontWeight"),
letterSpacing:input.css("letterSpacing"),
whiteSpace:"nowrap"
}), testerId = $(this).attr("id") + "_autosize_tester";
!$("#" + testerId).length > 0 && (testSubject.attr("id", testerId), testSubject.appendTo("body")), 
input.data("minwidth", minWidth), input.data("maxwidth", maxWidth), input.data("tester_id", testerId), 
input.css("width", minWidth);
}, $.fn.addTag = function(value, options) {
return options = jQuery.extend({
focus:!1,
callback:!0
}, options), this.each(function() {
var id = $(this).attr("id"), tagslist = $(this).val().split(delimiter[id]);
if ("" == tagslist[0] && (tagslist = new Array()), value = jQuery.trim(value), options.unique) {
var skipTag = $(this).tagExist(value);
1 == skipTag && $("#" + id + "_tag").addClass("not_valid");
} else var skipTag = !1;
if ("" != value && 1 != skipTag) {
if ($("<span>").addClass("tag").append($("<span>").text(value).append("&nbsp;&nbsp;"), $("<a>", {
href:"#",
title:"Removing tag",
text:"x"
}).click(function() {
return $("#" + id).removeTag(escape(value));
})).insertBefore("#" + id + "_addTag"), tagslist.push(value), $("#" + id + "_tag").val(""), 
options.focus ? $("#" + id + "_tag").focus() :$("#" + id + "_tag").blur(), $.fn.tagsInput.updateTagsField(this, tagslist), 
options.callback && tags_callbacks[id] && tags_callbacks[id].onAddTag) {
var f = tags_callbacks[id].onAddTag;
f.call(this, value);
}
if (!options.silent && tags_callbacks[id] && tags_callbacks[id].onChange) {
var i = tagslist.length, f = tags_callbacks[id].onChange;
f.call(this, $(this), tagslist[i - 1]);
}
}
}), !1;
}, $.fn.removeTag = function(value) {
return value = unescape(value), this.each(function() {
var id = $(this).attr("id"), old = $(this).val().split(delimiter[id]);
for ($("#" + id + "_tagsinput .tag").remove(), str = "", i = 0; i < old.length; i++) old[i] != value && (str = str + delimiter[id] + old[i]);
if ($.fn.tagsInput.silentImportTags(this, str), tags_callbacks[id] && tags_callbacks[id].onRemoveTag) {
var f = tags_callbacks[id].onRemoveTag;
f.call(this, value);
}
if (tags_callbacks[id] && tags_callbacks[id].onChange) {
var f = tags_callbacks[id].onChange;
f.call(this, $(this), []);
}
}), !1;
}, $.fn.tagExist = function(val) {
var id = $(this).attr("id"), tagslist = $(this).val().split(delimiter[id]);
return jQuery.inArray(val, tagslist) >= 0;
}, $.fn.importTags = function(str) {
id = $(this).attr("id"), $("#" + id + "_tagsinput .tag").remove(), $.fn.tagsInput.importTags(this, str);
}, $.fn.silentImportTags = function(str) {
id = $(this).attr("id"), $("#" + id + "_tagsinput .tag").remove(), $.fn.tagsInput.silentImportTags(this, str);
}, $.fn.tagsInput = function(options) {
var settings = jQuery.extend({
interactive:!0,
defaultText:"add a tag",
minChars:0,
width:"300px",
height:"100px",
autocomplete:{
selectFirst:!1
},
hide:!0,
delimiter:",",
unique:!0,
removeWithBackspace:!0,
placeholderColor:"#666666",
autosize:!0,
comfortZone:20,
inputPadding:12
}, options);
return this.each(function() {
settings.hide && $(this).hide();
var id = $(this).attr("id");
(!id || delimiter[$(this).attr("id")]) && (id = $(this).attr("id", "tags" + new Date().getTime()).attr("id"));
var data = jQuery.extend({
pid:id,
real_input:"#" + id,
holder:"#" + id + "_tagsinput",
input_wrapper:"#" + id + "_addTag",
fake_input:"#" + id + "_tag"
}, settings);
delimiter[id] = data.delimiter, (settings.onAddTag || settings.onRemoveTag || settings.onChange) && (tags_callbacks[id] = new Array(), 
tags_callbacks[id].onAddTag = settings.onAddTag, tags_callbacks[id].onRemoveTag = settings.onRemoveTag, 
tags_callbacks[id].onChange = settings.onChange);
var markup = '<div id="' + id + '_tagsinput" class="tagsinput"><div id="' + id + '_addTag">';
if (settings.interactive && (markup = markup + '<input id="' + id + '_tag" value="" data-default="' + settings.defaultText + '" />'), 
markup += '</div><div class="tags_clear"></div></div>', $(markup).insertAfter(this), 
$(data.holder).css("width", settings.width), $(data.holder).css("min-height", settings.height), 
$(data.holder).css("height", "100%"), "" != $(data.real_input).val() && $.fn.tagsInput.importTags($(data.real_input), $(data.real_input).val()), 
settings.interactive) {
if ($(data.fake_input).val($(data.fake_input).attr("data-default")), $(data.fake_input).css("color", settings.placeholderColor), 
$(data.fake_input).resetAutosize(settings), $(data.holder).bind("click", data, function(event) {
$(event.data.fake_input).focus();
}), $(data.fake_input).bind("focus", data, function(event) {
$(event.data.fake_input).val() == $(event.data.fake_input).attr("data-default") && $(event.data.fake_input).val(""), 
$(event.data.fake_input).css("color", "#000000");
}), void 0 != settings.autocomplete_url) {
autocomplete_options = {
source:settings.autocomplete_url
};
for (attrname in settings.autocomplete) autocomplete_options[attrname] = settings.autocomplete[attrname];
void 0 !== jQuery.Autocompleter ? ($(data.fake_input).autocomplete(settings.autocomplete_url, settings.autocomplete), 
$(data.fake_input).bind("result", data, function(event, data) {
data && $("#" + id).addTag(data[0] + "", {
focus:!0,
unique:settings.unique
});
})) :void 0 !== jQuery.ui.autocomplete && ($(data.fake_input).autocomplete(autocomplete_options), 
$(data.fake_input).bind("autocompleteselect", data, function(event, ui) {
return $(event.data.real_input).addTag(ui.item.value, {
focus:!0,
unique:settings.unique
}), !1;
}));
} else $(data.fake_input).bind("blur", data, function(event) {
var d = $(this).attr("data-default");
return "" != $(event.data.fake_input).val() && $(event.data.fake_input).val() != d ? event.data.minChars <= $(event.data.fake_input).val().length && (!event.data.maxChars || event.data.maxChars >= $(event.data.fake_input).val().length) && $(event.data.real_input).addTag($(event.data.fake_input).val(), {
focus:!0,
unique:settings.unique
}) :($(event.data.fake_input).val($(event.data.fake_input).attr("data-default")), 
$(event.data.fake_input).css("color", settings.placeholderColor)), !1;
});
$(data.fake_input).bind("keypress", data, function(event) {
return event.which == event.data.delimiter.charCodeAt(0) || 13 == event.which ? (event.preventDefault(), 
event.data.minChars <= $(event.data.fake_input).val().length && (!event.data.maxChars || event.data.maxChars >= $(event.data.fake_input).val().length) && $(event.data.real_input).addTag($(event.data.fake_input).val(), {
focus:!0,
unique:settings.unique
}), $(event.data.fake_input).resetAutosize(settings), !1) :(event.data.autosize && $(event.data.fake_input).doAutosize(settings), 
void 0);
}), data.removeWithBackspace && $(data.fake_input).bind("keydown", function(event) {
if (8 == event.keyCode && "" == $(this).val()) {
event.preventDefault();
var last_tag = $(this).closest(".tagsinput").find(".tag:last").text(), id = $(this).attr("id").replace(/_tag$/, "");
last_tag = last_tag.replace(/[\s]+x$/, ""), $("#" + id).removeTag(escape(last_tag)), 
$(this).trigger("focus");
}
}), $(data.fake_input).blur(), data.unique && $(data.fake_input).keydown(function(event) {
(8 == event.keyCode || String.fromCharCode(event.which).match(/\w+|[áéíóúÁÉÍÓÚñÑ,/]+/)) && $(this).removeClass("not_valid");
});
}
}), this;
}, $.fn.tagsInput.updateTagsField = function(obj, tagslist) {
var id = $(obj).attr("id");
$(obj).val(tagslist.join(delimiter[id]));
}, $.fn.tagsInput.importTags = function(obj, val) {
$(obj).val("");
var id = $(obj).attr("id"), tags = val.split(delimiter[id]);
for (i = 0; i < tags.length; i++) $(obj).addTag(tags[i], {
focus:!1,
callback:!1
});
if (tags_callbacks[id] && tags_callbacks[id].onChange) {
var f = tags_callbacks[id].onChange;
f.call(obj, obj, tags[i]);
}
}, $.fn.tagsInput.silentImportTags = function(obj, val) {
$(obj).val("");
var id = $(obj).attr("id"), tags = val.split(delimiter[id]);
for (i = 0; i < tags.length; i++) $(obj).addTag(tags[i], {
focus:!1,
callback:!1,
silent:!0
});
};
}(jQuery);