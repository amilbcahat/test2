HR.TRANSLATION_LANGUAGES = {
Chinese:"zh",
English:"en",
Japanese:"ja",
Russian:"ru"
};